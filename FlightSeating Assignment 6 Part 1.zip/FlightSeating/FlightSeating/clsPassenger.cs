﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace FlightSeating
{
    class clsPassenger
    {
        /// <summary>
        /// Passengers ID
        /// </summary>
        int passengerID;

        /// <summary>
        /// Passengers first name
        /// </summary>
        string firstName;

        /// <summary>
        /// Passengers last name
        /// </summary>
        string lastName;

        /// <summary>
        /// Passengers seat num
        /// </summary>
        public string seatNum;

        public clsPassenger(int pID, string fName, string lName)
        {
            passengerID = pID;
            firstName = fName;
            lastName = lName;
        }

        /// <summary>
        /// sets thte number func
        /// </summary>
        /// <param name="setNum"></param>

        public void setpassSeats(string setNum)
        {
            seatNum = setNum;
        }

        /// <summary>
        /// actually set seatNum
        /// </summary>
        /// <returns></returns>
        public string passSeats()
        {
            return seatNum; 
        }

        /// <summary>
        /// Overides the string format
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            try
            {
                return firstName + " " + lastName;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
            
        }

        /// <summary>
        /// Handle the error.
        /// </summary>
        /// <param name="sClass">The class in which the error occurred in.</param>
        /// <param name="sMethod">The method in which the error occurred in.</param>
        private void HandleError(string sClass, string sMethod, string sMessage)
        {
            try
            {
                //Would write to a file or database here.
                MessageBox.Show(sClass + "." + sMethod + " -> " + sMessage);
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllText("C:\\Error.txt", Environment.NewLine +
                                             "HandleError Exception: " + ex.Message);
            }
        }

    }
}
