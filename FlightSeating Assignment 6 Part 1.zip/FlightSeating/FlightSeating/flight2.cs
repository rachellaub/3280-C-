﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightSeating
{
    public partial class flight2 : UserControl
    {
        private Label lbl01;
        private Label lbl02;
        private Label lbl03;
        private Label lbl10;
        private Label lbl11;
        private Label lbl12;
        private Label lbl13;
        private Label lbl20;
        private Label lbl21;
        private Label lbl22;
        private Label lbl23;
        private Label lbl30;
        private Label lbl31;
        private Label lbl32;
        private Label lbl33;
        private Label lbl40;
        private Label lbl41;
        private Label lbl42;
        private Label lbl43;
        private Label label7;
        private Label lbl00;
    
        public flight2()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.lbl00 = new System.Windows.Forms.Label();
            this.lbl01 = new System.Windows.Forms.Label();
            this.lbl02 = new System.Windows.Forms.Label();
            this.lbl03 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.lbl11 = new System.Windows.Forms.Label();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl20 = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.lbl23 = new System.Windows.Forms.Label();
            this.lbl30 = new System.Windows.Forms.Label();
            this.lbl31 = new System.Windows.Forms.Label();
            this.lbl32 = new System.Windows.Forms.Label();
            this.lbl33 = new System.Windows.Forms.Label();
            this.lbl40 = new System.Windows.Forms.Label();
            this.lbl41 = new System.Windows.Forms.Label();
            this.lbl42 = new System.Windows.Forms.Label();
            this.lbl43 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl00
            // 
            this.lbl00.AutoSize = true;
            this.lbl00.BackColor = System.Drawing.Color.Blue;
            this.lbl00.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl00.ForeColor = System.Drawing.Color.Black;
            this.lbl00.Location = new System.Drawing.Point(48, 110);
            this.lbl00.Name = "lbl00";
            this.lbl00.Size = new System.Drawing.Size(106, 76);
            this.lbl00.TabIndex = 1;
            this.lbl00.Tag = "1";
            this.lbl00.Text = "  1";
            this.lbl00.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl01
            // 
            this.lbl01.AutoSize = true;
            this.lbl01.BackColor = System.Drawing.Color.Blue;
            this.lbl01.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl01.ForeColor = System.Drawing.Color.Black;
            this.lbl01.Location = new System.Drawing.Point(199, 110);
            this.lbl01.Name = "lbl01";
            this.lbl01.Size = new System.Drawing.Size(106, 76);
            this.lbl01.TabIndex = 2;
            this.lbl01.Tag = "2";
            this.lbl01.Text = "  2";
            this.lbl01.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl02
            // 
            this.lbl02.AutoSize = true;
            this.lbl02.BackColor = System.Drawing.Color.Blue;
            this.lbl02.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl02.ForeColor = System.Drawing.Color.Black;
            this.lbl02.Location = new System.Drawing.Point(444, 110);
            this.lbl02.Name = "lbl02";
            this.lbl02.Size = new System.Drawing.Size(106, 76);
            this.lbl02.TabIndex = 3;
            this.lbl02.Tag = "3";
            this.lbl02.Text = "  3";
            this.lbl02.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl03
            // 
            this.lbl03.AutoSize = true;
            this.lbl03.BackColor = System.Drawing.Color.Blue;
            this.lbl03.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl03.ForeColor = System.Drawing.Color.Black;
            this.lbl03.Location = new System.Drawing.Point(590, 110);
            this.lbl03.Name = "lbl03";
            this.lbl03.Size = new System.Drawing.Size(106, 76);
            this.lbl03.TabIndex = 4;
            this.lbl03.Tag = "4";
            this.lbl03.Text = "  4";
            this.lbl03.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl10
            // 
            this.lbl10.AutoSize = true;
            this.lbl10.BackColor = System.Drawing.Color.Blue;
            this.lbl10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl10.ForeColor = System.Drawing.Color.Black;
            this.lbl10.Location = new System.Drawing.Point(48, 232);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(106, 76);
            this.lbl10.TabIndex = 5;
            this.lbl10.Tag = "5";
            this.lbl10.Text = "  5";
            this.lbl10.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl11
            // 
            this.lbl11.AutoSize = true;
            this.lbl11.BackColor = System.Drawing.Color.Blue;
            this.lbl11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl11.ForeColor = System.Drawing.Color.Black;
            this.lbl11.Location = new System.Drawing.Point(199, 232);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(106, 76);
            this.lbl11.TabIndex = 6;
            this.lbl11.Tag = "6";
            this.lbl11.Text = "  6";
            this.lbl11.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl12
            // 
            this.lbl12.AutoSize = true;
            this.lbl12.BackColor = System.Drawing.Color.Blue;
            this.lbl12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl12.ForeColor = System.Drawing.Color.Black;
            this.lbl12.Location = new System.Drawing.Point(444, 232);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(106, 76);
            this.lbl12.TabIndex = 7;
            this.lbl12.Tag = "7";
            this.lbl12.Text = "  7";
            this.lbl12.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl13
            // 
            this.lbl13.AutoSize = true;
            this.lbl13.BackColor = System.Drawing.Color.Blue;
            this.lbl13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl13.ForeColor = System.Drawing.Color.Black;
            this.lbl13.Location = new System.Drawing.Point(590, 232);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(106, 76);
            this.lbl13.TabIndex = 8;
            this.lbl13.Tag = "8";
            this.lbl13.Text = "  8";
            this.lbl13.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl20
            // 
            this.lbl20.AutoSize = true;
            this.lbl20.BackColor = System.Drawing.Color.Blue;
            this.lbl20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl20.ForeColor = System.Drawing.Color.Black;
            this.lbl20.Location = new System.Drawing.Point(48, 343);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(106, 76);
            this.lbl20.TabIndex = 9;
            this.lbl20.Tag = "9";
            this.lbl20.Text = "  9";
            this.lbl20.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl21
            // 
            this.lbl21.AutoSize = true;
            this.lbl21.BackColor = System.Drawing.Color.Blue;
            this.lbl21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl21.ForeColor = System.Drawing.Color.Black;
            this.lbl21.Location = new System.Drawing.Point(198, 343);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(107, 76);
            this.lbl21.TabIndex = 10;
            this.lbl21.Tag = "10";
            this.lbl21.Text = "10";
            this.lbl21.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl22
            // 
            this.lbl22.AutoSize = true;
            this.lbl22.BackColor = System.Drawing.Color.Blue;
            this.lbl22.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl22.ForeColor = System.Drawing.Color.Black;
            this.lbl22.Location = new System.Drawing.Point(444, 343);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(107, 76);
            this.lbl22.TabIndex = 11;
            this.lbl22.Tag = "11";
            this.lbl22.Text = "11";
            this.lbl22.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl23
            // 
            this.lbl23.AutoSize = true;
            this.lbl23.BackColor = System.Drawing.Color.Blue;
            this.lbl23.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl23.ForeColor = System.Drawing.Color.Black;
            this.lbl23.Location = new System.Drawing.Point(590, 343);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(107, 76);
            this.lbl23.TabIndex = 12;
            this.lbl23.Tag = "12";
            this.lbl23.Text = "12";
            this.lbl23.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl30
            // 
            this.lbl30.AutoSize = true;
            this.lbl30.BackColor = System.Drawing.Color.Blue;
            this.lbl30.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl30.ForeColor = System.Drawing.Color.Black;
            this.lbl30.Location = new System.Drawing.Point(48, 458);
            this.lbl30.Name = "lbl30";
            this.lbl30.Size = new System.Drawing.Size(107, 76);
            this.lbl30.TabIndex = 13;
            this.lbl30.Tag = "13";
            this.lbl30.Text = "13";
            this.lbl30.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl31
            // 
            this.lbl31.AutoSize = true;
            this.lbl31.BackColor = System.Drawing.Color.Blue;
            this.lbl31.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl31.ForeColor = System.Drawing.Color.Black;
            this.lbl31.Location = new System.Drawing.Point(198, 458);
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(107, 76);
            this.lbl31.TabIndex = 14;
            this.lbl31.Tag = "14";
            this.lbl31.Text = "14";
            this.lbl31.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl32
            // 
            this.lbl32.AutoSize = true;
            this.lbl32.BackColor = System.Drawing.Color.Blue;
            this.lbl32.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl32.ForeColor = System.Drawing.Color.Black;
            this.lbl32.Location = new System.Drawing.Point(443, 458);
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(107, 76);
            this.lbl32.TabIndex = 15;
            this.lbl32.Tag = "15";
            this.lbl32.Text = "15";
            this.lbl32.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl33
            // 
            this.lbl33.AutoSize = true;
            this.lbl33.BackColor = System.Drawing.Color.Blue;
            this.lbl33.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl33.ForeColor = System.Drawing.Color.Black;
            this.lbl33.Location = new System.Drawing.Point(589, 458);
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(107, 76);
            this.lbl33.TabIndex = 16;
            this.lbl33.Tag = "16";
            this.lbl33.Text = "16";
            this.lbl33.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl40
            // 
            this.lbl40.AutoSize = true;
            this.lbl40.BackColor = System.Drawing.Color.Blue;
            this.lbl40.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl40.ForeColor = System.Drawing.Color.Black;
            this.lbl40.Location = new System.Drawing.Point(48, 573);
            this.lbl40.Name = "lbl40";
            this.lbl40.Size = new System.Drawing.Size(107, 76);
            this.lbl40.TabIndex = 17;
            this.lbl40.Tag = "17";
            this.lbl40.Text = "17";
            this.lbl40.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl41
            // 
            this.lbl41.AutoSize = true;
            this.lbl41.BackColor = System.Drawing.Color.Blue;
            this.lbl41.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl41.ForeColor = System.Drawing.Color.Black;
            this.lbl41.Location = new System.Drawing.Point(198, 573);
            this.lbl41.Name = "lbl41";
            this.lbl41.Size = new System.Drawing.Size(107, 76);
            this.lbl41.TabIndex = 18;
            this.lbl41.Tag = "18";
            this.lbl41.Text = "18";
            this.lbl41.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl42
            // 
            this.lbl42.AutoSize = true;
            this.lbl42.BackColor = System.Drawing.Color.Blue;
            this.lbl42.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl42.ForeColor = System.Drawing.Color.Black;
            this.lbl42.Location = new System.Drawing.Point(443, 573);
            this.lbl42.Name = "lbl42";
            this.lbl42.Size = new System.Drawing.Size(107, 76);
            this.lbl42.TabIndex = 19;
            this.lbl42.Tag = "19";
            this.lbl42.Text = "19";
            this.lbl42.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl43
            // 
            this.lbl43.AutoSize = true;
            this.lbl43.BackColor = System.Drawing.Color.Blue;
            this.lbl43.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl43.ForeColor = System.Drawing.Color.Black;
            this.lbl43.Location = new System.Drawing.Point(590, 573);
            this.lbl43.Name = "lbl43";
            this.lbl43.Size = new System.Drawing.Size(107, 76);
            this.lbl43.TabIndex = 20;
            this.lbl43.Tag = "20";
            this.lbl43.Text = "20";
            this.lbl43.Click += new System.EventHandler(this.Seat_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label7.Location = new System.Drawing.Point(179, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(353, 52);
            this.label7.TabIndex = 64;
            this.label7.Text = "412 - Boeing 767";
            // 
            // flight2
            // 
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbl43);
            this.Controls.Add(this.lbl42);
            this.Controls.Add(this.lbl41);
            this.Controls.Add(this.lbl40);
            this.Controls.Add(this.lbl33);
            this.Controls.Add(this.lbl32);
            this.Controls.Add(this.lbl31);
            this.Controls.Add(this.lbl30);
            this.Controls.Add(this.lbl23);
            this.Controls.Add(this.lbl22);
            this.Controls.Add(this.lbl21);
            this.Controls.Add(this.lbl20);
            this.Controls.Add(this.lbl13);
            this.Controls.Add(this.lbl12);
            this.Controls.Add(this.lbl11);
            this.Controls.Add(this.lbl10);
            this.Controls.Add(this.lbl03);
            this.Controls.Add(this.lbl02);
            this.Controls.Add(this.lbl01);
            this.Controls.Add(this.lbl00);
            this.Name = "flight2";
            this.Size = new System.Drawing.Size(745, 707);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void Seat_Click(object sender, EventArgs e)
        {

        }
    }
}
