﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace FlightSeating
{
    public partial class Flights : Form
    {
        /// <summary>
        /// Helps grab information for combo box on flights
        /// </summary>
        clsFlightManager flightManager;

        /// <summary>
        /// Helps grab information for passenger combo box
        /// </summary>
        addPassenger addPass;

        /// <summary>
        /// variable deteching which flight was selected
        /// </summary>
        bool var = false;

        public Flights()
        {
            InitializeComponent();
            flightManager = new clsFlightManager();
            addPass = new addPassenger();
           
            populateFlights();
            populatePassengers();


            cmbFlight.SelectedIndex = -1;
            //flightManager = new clsFlightManager();
        }


        /// <summary>
        /// Populates the flights
        /// </summary>
        public void populateFlights()
        {
            try
            {
                List<clsFlight> flightList = new List<clsFlight>(); //flights list
                flightList = flightManager.flightList();

                //cmbFlight.DataSource = flightList;////////////////////////Bind the list to the combo box

                for (int i = 0; i < flightList.Count; i++)
                {
                    cmbFlight.Items.Add(flightList[i]);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }

        }

        /// <summary>
        /// Populates the passengers
        /// </summary>
        public void populatePassengers()
        {
            try
            {
                if (cmbPassenger.Items.Count != 0)
                {
                    cmbPassenger.Items.Clear();
                }
                List<clsPassenger> passengerList = new List<clsPassenger>();
                passengerList = flightManager.passengers(var);

                //cmbPassenger.DataSource = passengerList;
                for (int i = 0; i < passengerList.Count; i++)
                {
                    cmbPassenger.Items.Add(passengerList[i]);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }


        }

        /// <summary>
        /// Controls the Add Passenger window UI
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addPassButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                //Show the user data form
                addPass.ShowDialog();
                //Show the main form
                this.Show();
            }
            catch (Exception ex)
            {
                //This is the top level method so we want to handle the exception
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }

        }

        /// <summary>
        /// loads the seating charts and populates the passengers
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmbFlight_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                enableFunction();
                if (cmbFlight.SelectedIndex == 0)
                {
                    flight21.Visible = false;
                    flight11.Visible = true;
                    var = true;
                    populatePassengers();
                }
                else
                {
                    flight11.Visible = false;
                    flight21.Visible = true;
                    var = false;
                    populatePassengers();
                }
            }
            catch (Exception ex)
            {
                //This is the top level method so we want to handle the exception
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Enables everything after flight chosen
        /// </summary>
        private void enableFunction()
        {
            try
            {
                cmbPassenger.Enabled = true;
                txtSeat.Enabled = true;
                addPassButton.Enabled = true;
                chgSeatButton.Enabled = true;
                delPassButton.Enabled = true;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }

        }

        /// <summary>
        /// Handle the error.
        /// </summary>
        /// <param name="sClass">The class in which the error occurred in.</param>
        /// <param name="sMethod">The method in which the error occurred in.</param>
        private void HandleError(string sClass, string sMethod, string sMessage)
        {
            try
            {
                //Would write to a file or database here.
                MessageBox.Show(sClass + "." + sMethod + " -> " + sMessage);
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllText("C:\\Error.txt", Environment.NewLine +
                                             "HandleError Exception: " + ex.Message);
            }
        }

    }
}
