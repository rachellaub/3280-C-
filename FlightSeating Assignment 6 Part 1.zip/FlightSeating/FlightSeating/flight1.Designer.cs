﻿namespace FlightSeating
{
    partial class userControlFlight1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl00 = new System.Windows.Forms.Label();
            this.lbl01 = new System.Windows.Forms.Label();
            this.lbl03 = new System.Windows.Forms.Label();
            this.lbl02 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.lbl11 = new System.Windows.Forms.Label();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl13 = new System.Windows.Forms.Label();
            this.lbl15 = new System.Windows.Forms.Label();
            this.lbl14 = new System.Windows.Forms.Label();
            this.lbl20 = new System.Windows.Forms.Label();
            this.lbl25 = new System.Windows.Forms.Label();
            this.lbl24 = new System.Windows.Forms.Label();
            this.lbl23 = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.lbl41 = new System.Windows.Forms.Label();
            this.lbl40 = new System.Windows.Forms.Label();
            this.lbl35 = new System.Windows.Forms.Label();
            this.lbl34 = new System.Windows.Forms.Label();
            this.lbl33 = new System.Windows.Forms.Label();
            this.lbl32 = new System.Windows.Forms.Label();
            this.lbl31 = new System.Windows.Forms.Label();
            this.lbl30 = new System.Windows.Forms.Label();
            this.lbl42 = new System.Windows.Forms.Label();
            this.lbl43 = new System.Windows.Forms.Label();
            this.lbl44 = new System.Windows.Forms.Label();
            this.lbl45 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl00
            // 
            this.lbl00.AutoSize = true;
            this.lbl00.BackColor = System.Drawing.Color.Blue;
            this.lbl00.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl00.ForeColor = System.Drawing.Color.Black;
            this.lbl00.Location = new System.Drawing.Point(159, 85);
            this.lbl00.Name = "lbl00";
            this.lbl00.Size = new System.Drawing.Size(106, 76);
            this.lbl00.TabIndex = 1;
            this.lbl00.Tag = "1";
            this.lbl00.Text = "  1";
            this.lbl00.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl01
            // 
            this.lbl01.AutoSize = true;
            this.lbl01.BackColor = System.Drawing.Color.Blue;
            this.lbl01.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl01.ForeColor = System.Drawing.Color.Black;
            this.lbl01.Location = new System.Drawing.Point(300, 85);
            this.lbl01.Name = "lbl01";
            this.lbl01.Size = new System.Drawing.Size(106, 76);
            this.lbl01.TabIndex = 2;
            this.lbl01.Tag = "2";
            this.lbl01.Text = "  2";
            this.lbl01.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl03
            // 
            this.lbl03.AutoSize = true;
            this.lbl03.BackColor = System.Drawing.Color.Blue;
            this.lbl03.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl03.ForeColor = System.Drawing.Color.Black;
            this.lbl03.Location = new System.Drawing.Point(700, 85);
            this.lbl03.Name = "lbl03";
            this.lbl03.Size = new System.Drawing.Size(106, 76);
            this.lbl03.TabIndex = 4;
            this.lbl03.Tag = "4";
            this.lbl03.Text = "  4";
            this.lbl03.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl02
            // 
            this.lbl02.AutoSize = true;
            this.lbl02.BackColor = System.Drawing.Color.Blue;
            this.lbl02.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl02.ForeColor = System.Drawing.Color.Black;
            this.lbl02.Location = new System.Drawing.Point(553, 85);
            this.lbl02.Name = "lbl02";
            this.lbl02.Size = new System.Drawing.Size(106, 76);
            this.lbl02.TabIndex = 3;
            this.lbl02.Tag = "3";
            this.lbl02.Text = "  3";
            this.lbl02.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl10
            // 
            this.lbl10.AutoSize = true;
            this.lbl10.BackColor = System.Drawing.Color.Blue;
            this.lbl10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl10.ForeColor = System.Drawing.Color.Black;
            this.lbl10.Location = new System.Drawing.Point(30, 209);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(106, 76);
            this.lbl10.TabIndex = 5;
            this.lbl10.Tag = "5";
            this.lbl10.Text = "  5";
            this.lbl10.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl11
            // 
            this.lbl11.AutoSize = true;
            this.lbl11.BackColor = System.Drawing.Color.Blue;
            this.lbl11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl11.ForeColor = System.Drawing.Color.Black;
            this.lbl11.Location = new System.Drawing.Point(159, 209);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(106, 76);
            this.lbl11.TabIndex = 6;
            this.lbl11.Tag = "6";
            this.lbl11.Text = "  6";
            this.lbl11.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl12
            // 
            this.lbl12.AutoSize = true;
            this.lbl12.BackColor = System.Drawing.Color.Blue;
            this.lbl12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl12.ForeColor = System.Drawing.Color.Black;
            this.lbl12.Location = new System.Drawing.Point(300, 209);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(106, 76);
            this.lbl12.TabIndex = 7;
            this.lbl12.Tag = "7";
            this.lbl12.Text = "  7";
            this.lbl12.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl13
            // 
            this.lbl13.AutoSize = true;
            this.lbl13.BackColor = System.Drawing.Color.Blue;
            this.lbl13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl13.ForeColor = System.Drawing.Color.Black;
            this.lbl13.Location = new System.Drawing.Point(553, 209);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(106, 76);
            this.lbl13.TabIndex = 8;
            this.lbl13.Tag = "8";
            this.lbl13.Text = "  8";
            this.lbl13.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl15
            // 
            this.lbl15.AutoSize = true;
            this.lbl15.BackColor = System.Drawing.Color.Blue;
            this.lbl15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl15.ForeColor = System.Drawing.Color.Black;
            this.lbl15.Location = new System.Drawing.Point(833, 209);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(107, 76);
            this.lbl15.TabIndex = 10;
            this.lbl15.Tag = "10";
            this.lbl15.Text = "10";
            this.lbl15.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl14
            // 
            this.lbl14.AutoSize = true;
            this.lbl14.BackColor = System.Drawing.Color.Blue;
            this.lbl14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl14.ForeColor = System.Drawing.Color.Black;
            this.lbl14.Location = new System.Drawing.Point(700, 209);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(106, 76);
            this.lbl14.TabIndex = 9;
            this.lbl14.Tag = "9";
            this.lbl14.Text = "  9";
            this.lbl14.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl20
            // 
            this.lbl20.AutoSize = true;
            this.lbl20.BackColor = System.Drawing.Color.Blue;
            this.lbl20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl20.ForeColor = System.Drawing.Color.Black;
            this.lbl20.Location = new System.Drawing.Point(30, 330);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(107, 76);
            this.lbl20.TabIndex = 11;
            this.lbl20.Tag = "11";
            this.lbl20.Text = "11";
            this.lbl20.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl25
            // 
            this.lbl25.AutoSize = true;
            this.lbl25.BackColor = System.Drawing.Color.Blue;
            this.lbl25.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl25.ForeColor = System.Drawing.Color.Black;
            this.lbl25.Location = new System.Drawing.Point(833, 330);
            this.lbl25.Name = "lbl25";
            this.lbl25.Size = new System.Drawing.Size(107, 76);
            this.lbl25.TabIndex = 16;
            this.lbl25.Tag = "16";
            this.lbl25.Text = "16";
            this.lbl25.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl24
            // 
            this.lbl24.AutoSize = true;
            this.lbl24.BackColor = System.Drawing.Color.Blue;
            this.lbl24.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl24.ForeColor = System.Drawing.Color.Black;
            this.lbl24.Location = new System.Drawing.Point(700, 330);
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(107, 76);
            this.lbl24.TabIndex = 15;
            this.lbl24.Tag = "15";
            this.lbl24.Text = "15";
            this.lbl24.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl23
            // 
            this.lbl23.AutoSize = true;
            this.lbl23.BackColor = System.Drawing.Color.Blue;
            this.lbl23.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl23.ForeColor = System.Drawing.Color.Black;
            this.lbl23.Location = new System.Drawing.Point(553, 330);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(107, 76);
            this.lbl23.TabIndex = 14;
            this.lbl23.Tag = "14";
            this.lbl23.Text = "14";
            this.lbl23.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl22
            // 
            this.lbl22.AutoSize = true;
            this.lbl22.BackColor = System.Drawing.Color.Blue;
            this.lbl22.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl22.ForeColor = System.Drawing.Color.Black;
            this.lbl22.Location = new System.Drawing.Point(300, 330);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(107, 76);
            this.lbl22.TabIndex = 13;
            this.lbl22.Tag = "13";
            this.lbl22.Text = "13";
            this.lbl22.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl21
            // 
            this.lbl21.AutoSize = true;
            this.lbl21.BackColor = System.Drawing.Color.Blue;
            this.lbl21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl21.ForeColor = System.Drawing.Color.Black;
            this.lbl21.Location = new System.Drawing.Point(159, 330);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(107, 76);
            this.lbl21.TabIndex = 12;
            this.lbl21.Tag = "12";
            this.lbl21.Text = "12";
            this.lbl21.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl41
            // 
            this.lbl41.AutoSize = true;
            this.lbl41.BackColor = System.Drawing.Color.Blue;
            this.lbl41.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl41.ForeColor = System.Drawing.Color.Black;
            this.lbl41.Location = new System.Drawing.Point(159, 555);
            this.lbl41.Name = "lbl41";
            this.lbl41.Size = new System.Drawing.Size(107, 76);
            this.lbl41.TabIndex = 24;
            this.lbl41.Tag = "24";
            this.lbl41.Text = "24";
            this.lbl41.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl40
            // 
            this.lbl40.AutoSize = true;
            this.lbl40.BackColor = System.Drawing.Color.Blue;
            this.lbl40.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl40.ForeColor = System.Drawing.Color.Black;
            this.lbl40.Location = new System.Drawing.Point(30, 555);
            this.lbl40.Name = "lbl40";
            this.lbl40.Size = new System.Drawing.Size(107, 76);
            this.lbl40.TabIndex = 23;
            this.lbl40.Tag = "23";
            this.lbl40.Text = "23";
            this.lbl40.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl35
            // 
            this.lbl35.AutoSize = true;
            this.lbl35.BackColor = System.Drawing.Color.Blue;
            this.lbl35.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl35.ForeColor = System.Drawing.Color.Black;
            this.lbl35.Location = new System.Drawing.Point(833, 443);
            this.lbl35.Name = "lbl35";
            this.lbl35.Size = new System.Drawing.Size(107, 76);
            this.lbl35.TabIndex = 22;
            this.lbl35.Tag = "22";
            this.lbl35.Text = "22";
            this.lbl35.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl34
            // 
            this.lbl34.AutoSize = true;
            this.lbl34.BackColor = System.Drawing.Color.Blue;
            this.lbl34.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl34.ForeColor = System.Drawing.Color.Black;
            this.lbl34.Location = new System.Drawing.Point(700, 443);
            this.lbl34.Name = "lbl34";
            this.lbl34.Size = new System.Drawing.Size(107, 76);
            this.lbl34.TabIndex = 21;
            this.lbl34.Tag = "21";
            this.lbl34.Text = "21";
            this.lbl34.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl33
            // 
            this.lbl33.AutoSize = true;
            this.lbl33.BackColor = System.Drawing.Color.Blue;
            this.lbl33.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl33.ForeColor = System.Drawing.Color.Black;
            this.lbl33.Location = new System.Drawing.Point(553, 443);
            this.lbl33.Name = "lbl33";
            this.lbl33.Size = new System.Drawing.Size(107, 76);
            this.lbl33.TabIndex = 20;
            this.lbl33.Tag = "20";
            this.lbl33.Text = "20";
            this.lbl33.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl32
            // 
            this.lbl32.AutoSize = true;
            this.lbl32.BackColor = System.Drawing.Color.Blue;
            this.lbl32.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl32.ForeColor = System.Drawing.Color.Black;
            this.lbl32.Location = new System.Drawing.Point(300, 443);
            this.lbl32.Name = "lbl32";
            this.lbl32.Size = new System.Drawing.Size(107, 76);
            this.lbl32.TabIndex = 19;
            this.lbl32.Tag = "19";
            this.lbl32.Text = "19";
            this.lbl32.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl31
            // 
            this.lbl31.AutoSize = true;
            this.lbl31.BackColor = System.Drawing.Color.Blue;
            this.lbl31.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl31.ForeColor = System.Drawing.Color.Black;
            this.lbl31.Location = new System.Drawing.Point(159, 443);
            this.lbl31.Name = "lbl31";
            this.lbl31.Size = new System.Drawing.Size(107, 76);
            this.lbl31.TabIndex = 18;
            this.lbl31.Tag = "18";
            this.lbl31.Text = "18";
            this.lbl31.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl30
            // 
            this.lbl30.AutoSize = true;
            this.lbl30.BackColor = System.Drawing.Color.Blue;
            this.lbl30.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl30.ForeColor = System.Drawing.Color.Black;
            this.lbl30.Location = new System.Drawing.Point(30, 443);
            this.lbl30.Name = "lbl30";
            this.lbl30.Size = new System.Drawing.Size(107, 76);
            this.lbl30.TabIndex = 17;
            this.lbl30.Tag = "17";
            this.lbl30.Text = "17";
            this.lbl30.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl42
            // 
            this.lbl42.AutoSize = true;
            this.lbl42.BackColor = System.Drawing.Color.Blue;
            this.lbl42.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl42.ForeColor = System.Drawing.Color.Black;
            this.lbl42.Location = new System.Drawing.Point(300, 555);
            this.lbl42.Name = "lbl42";
            this.lbl42.Size = new System.Drawing.Size(107, 76);
            this.lbl42.TabIndex = 25;
            this.lbl42.Tag = "25";
            this.lbl42.Text = "25";
            this.lbl42.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl43
            // 
            this.lbl43.AutoSize = true;
            this.lbl43.BackColor = System.Drawing.Color.Blue;
            this.lbl43.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl43.ForeColor = System.Drawing.Color.Black;
            this.lbl43.Location = new System.Drawing.Point(553, 555);
            this.lbl43.Name = "lbl43";
            this.lbl43.Size = new System.Drawing.Size(107, 76);
            this.lbl43.TabIndex = 26;
            this.lbl43.Tag = "26";
            this.lbl43.Text = "26";
            this.lbl43.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl44
            // 
            this.lbl44.AutoSize = true;
            this.lbl44.BackColor = System.Drawing.Color.Blue;
            this.lbl44.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl44.ForeColor = System.Drawing.Color.Black;
            this.lbl44.Location = new System.Drawing.Point(700, 555);
            this.lbl44.Name = "lbl44";
            this.lbl44.Size = new System.Drawing.Size(107, 76);
            this.lbl44.TabIndex = 27;
            this.lbl44.Tag = "27";
            this.lbl44.Text = "27";
            this.lbl44.Click += new System.EventHandler(this.Seat_Click);
            // 
            // lbl45
            // 
            this.lbl45.AutoSize = true;
            this.lbl45.BackColor = System.Drawing.Color.Blue;
            this.lbl45.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl45.ForeColor = System.Drawing.Color.Black;
            this.lbl45.Location = new System.Drawing.Point(833, 555);
            this.lbl45.Name = "lbl45";
            this.lbl45.Size = new System.Drawing.Size(107, 76);
            this.lbl45.TabIndex = 28;
            this.lbl45.Tag = "28";
            this.lbl45.Text = "28";
            this.lbl45.Click += new System.EventHandler(this.Seat_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label7.Location = new System.Drawing.Point(304, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(371, 52);
            this.label7.TabIndex = 42;
            this.label7.Text = "102 - Airbus A380";
            // 
            // userControlFlight1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbl45);
            this.Controls.Add(this.lbl44);
            this.Controls.Add(this.lbl43);
            this.Controls.Add(this.lbl42);
            this.Controls.Add(this.lbl30);
            this.Controls.Add(this.lbl31);
            this.Controls.Add(this.lbl32);
            this.Controls.Add(this.lbl33);
            this.Controls.Add(this.lbl34);
            this.Controls.Add(this.lbl35);
            this.Controls.Add(this.lbl40);
            this.Controls.Add(this.lbl41);
            this.Controls.Add(this.lbl21);
            this.Controls.Add(this.lbl22);
            this.Controls.Add(this.lbl23);
            this.Controls.Add(this.lbl24);
            this.Controls.Add(this.lbl25);
            this.Controls.Add(this.lbl20);
            this.Controls.Add(this.lbl14);
            this.Controls.Add(this.lbl15);
            this.Controls.Add(this.lbl13);
            this.Controls.Add(this.lbl12);
            this.Controls.Add(this.lbl11);
            this.Controls.Add(this.lbl10);
            this.Controls.Add(this.lbl02);
            this.Controls.Add(this.lbl03);
            this.Controls.Add(this.lbl01);
            this.Controls.Add(this.lbl00);
            this.Name = "userControlFlight1";
            this.Size = new System.Drawing.Size(1097, 880);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl00;
        private System.Windows.Forms.Label lbl01;
        private System.Windows.Forms.Label lbl03;
        private System.Windows.Forms.Label lbl02;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl13;
        private System.Windows.Forms.Label lbl15;
        private System.Windows.Forms.Label lbl14;
        private System.Windows.Forms.Label lbl20;
        private System.Windows.Forms.Label lbl25;
        private System.Windows.Forms.Label lbl24;
        private System.Windows.Forms.Label lbl23;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Label lbl41;
        private System.Windows.Forms.Label lbl40;
        private System.Windows.Forms.Label lbl35;
        private System.Windows.Forms.Label lbl34;
        private System.Windows.Forms.Label lbl33;
        private System.Windows.Forms.Label lbl32;
        private System.Windows.Forms.Label lbl31;
        private System.Windows.Forms.Label lbl30;
        private System.Windows.Forms.Label lbl42;
        private System.Windows.Forms.Label lbl43;
        private System.Windows.Forms.Label lbl44;
        private System.Windows.Forms.Label lbl45;
        private System.Windows.Forms.Label label7;

    }
}
