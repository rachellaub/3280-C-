﻿namespace FlightSeating
{
    partial class Flights
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbFlight = new System.Windows.Forms.ComboBox();
            this.cmbPassenger = new System.Windows.Forms.ComboBox();
            this.txtSeat = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.chgSeatButton = new System.Windows.Forms.Button();
            this.addPassButton = new System.Windows.Forms.Button();
            this.delPassButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.flight21 = new FlightSeating.flight2();
            this.flight11 = new FlightSeating.userControlFlight1();
            this.lblStatus = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmbFlight
            // 
            this.cmbFlight.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cmbFlight.FormattingEnabled = true;
            this.cmbFlight.Location = new System.Drawing.Point(1462, 135);
            this.cmbFlight.Name = "cmbFlight";
            this.cmbFlight.Size = new System.Drawing.Size(443, 54);
            this.cmbFlight.TabIndex = 0;
            this.cmbFlight.SelectedIndexChanged += new System.EventHandler(this.cmbFlight_SelectedIndexChanged);
            this.cmbFlight.SelectedValueChanged += new System.EventHandler(this.cmbFlight_SelectedIndexChanged);
            // 
            // cmbPassenger
            // 
            this.cmbPassenger.Enabled = false;
            this.cmbPassenger.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.cmbPassenger.FormattingEnabled = true;
            this.cmbPassenger.Location = new System.Drawing.Point(1462, 248);
            this.cmbPassenger.Name = "cmbPassenger";
            this.cmbPassenger.Size = new System.Drawing.Size(443, 54);
            this.cmbPassenger.TabIndex = 1;
            // 
            // txtSeat
            // 
            this.txtSeat.Enabled = false;
            this.txtSeat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtSeat.Location = new System.Drawing.Point(1462, 360);
            this.txtSeat.Name = "txtSeat";
            this.txtSeat.Size = new System.Drawing.Size(443, 53);
            this.txtSeat.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label1.Location = new System.Drawing.Point(1113, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(304, 52);
            this.label1.TabIndex = 3;
            this.label1.Text = "Choose Flight:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label2.Location = new System.Drawing.Point(1012, 247);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(405, 52);
            this.label2.TabIndex = 4;
            this.label2.Text = "Choose Passenger:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label3.Location = new System.Drawing.Point(1043, 360);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(374, 52);
            this.label3.TabIndex = 5;
            this.label3.Text = "Passenger\'s Seat:";
            // 
            // chgSeatButton
            // 
            this.chgSeatButton.Enabled = false;
            this.chgSeatButton.Location = new System.Drawing.Point(1663, 508);
            this.chgSeatButton.Name = "chgSeatButton";
            this.chgSeatButton.Size = new System.Drawing.Size(242, 85);
            this.chgSeatButton.TabIndex = 6;
            this.chgSeatButton.Text = "Change Seat";
            this.chgSeatButton.UseVisualStyleBackColor = true;
            // 
            // addPassButton
            // 
            this.addPassButton.Enabled = false;
            this.addPassButton.Location = new System.Drawing.Point(1347, 643);
            this.addPassButton.Name = "addPassButton";
            this.addPassButton.Size = new System.Drawing.Size(242, 85);
            this.addPassButton.TabIndex = 7;
            this.addPassButton.Text = "Add Passenger";
            this.addPassButton.UseVisualStyleBackColor = true;
            this.addPassButton.Click += new System.EventHandler(this.addPassButton_Click);
            // 
            // delPassButton
            // 
            this.delPassButton.Enabled = false;
            this.delPassButton.Location = new System.Drawing.Point(1663, 643);
            this.delPassButton.Name = "delPassButton";
            this.delPassButton.Size = new System.Drawing.Size(242, 85);
            this.delPassButton.TabIndex = 8;
            this.delPassButton.Text = "Delete Passenger";
            this.delPassButton.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.groupBox1.Location = new System.Drawing.Point(1082, 772);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(952, 429);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Color Key";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label9.Location = new System.Drawing.Point(244, 323);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(528, 52);
            this.label9.TabIndex = 12;
            this.label9.Text = "Selected Passengers seat";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label8.Location = new System.Drawing.Point(244, 208);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(287, 52);
            this.label8.TabIndex = 11;
            this.label8.Text = "Seat is empty";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.label7.Location = new System.Drawing.Point(244, 86);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(274, 52);
            this.label7.TabIndex = 10;
            this.label7.Text = "Seat is taken";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.LimeGreen;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label6.ForeColor = System.Drawing.Color.LimeGreen;
            this.label6.Location = new System.Drawing.Point(53, 314);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 76);
            this.label6.TabIndex = 2;
            this.label6.Text = " H";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Blue;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(53, 196);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 76);
            this.label5.TabIndex = 1;
            this.label5.Text = " H";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Red;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(53, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 76);
            this.label4.TabIndex = 0;
            this.label4.Text = " H";
            // 
            // flight21
            // 
            this.flight21.Location = new System.Drawing.Point(154, 167);
            this.flight21.Name = "flight21";
            this.flight21.Size = new System.Drawing.Size(745, 707);
            this.flight21.TabIndex = 11;
            this.flight21.Visible = false;
            // 
            // flight11
            // 
            this.flight11.Location = new System.Drawing.Point(34, 151);
            this.flight11.Name = "flight11";
            this.flight11.Size = new System.Drawing.Size(972, 866);
            this.flight11.TabIndex = 10;
            this.flight11.Visible = false;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.lblStatus.Location = new System.Drawing.Point(1338, 508);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(0, 52);
            this.lblStatus.TabIndex = 12;
            // 
            // Flights
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2075, 1252);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.flight21);
            this.Controls.Add(this.flight11);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.delPassButton);
            this.Controls.Add(this.addPassButton);
            this.Controls.Add(this.chgSeatButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSeat);
            this.Controls.Add(this.cmbPassenger);
            this.Controls.Add(this.cmbFlight);
            this.Name = "Flights";
            this.Text = "Flights";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbFlight;
        private System.Windows.Forms.ComboBox cmbPassenger;
        private System.Windows.Forms.TextBox txtSeat;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button chgSeatButton;
        private System.Windows.Forms.Button addPassButton;
        private System.Windows.Forms.Button delPassButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private userControlFlight1 flight11;
        private flight2 flight21;
        private System.Windows.Forms.Label lblStatus;
    }
}

