﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Reflection;

namespace FlightSeating
{

    class clsFlightManager
    {
        /// <summary>
        /// Creates the database connecting to the clsDataAccess
        /// </summary>
        clsDataAccess db = new clsDataAccess();

        /// <summary>
        /// Creates a flight List
        /// Then uses sql to grab flight information
        /// which is added to the list
        /// </summary>
        /// <returns></returns>
        public List<clsFlight> flightList()
        {
             try
            {
            List<clsFlight> flightList = new List<clsFlight>(); //flights list


            int iRet = 0;   //Number of return values
            DataSet ds; //Holds the return values

            ds = db.ExecuteSQLStatement("SELECT Flight_ID, Flight_Number, Aircraft_Type FROM FLIGHT", ref iRet);


            for (int i = 0; i < iRet; i++)
            {
                string flightID = ds.Tables[0].Rows[i][0].ToString();
                string flightNum = ds.Tables[0].Rows[i][1].ToString();
                string aircraftType = ds.Tables[0].Rows[i][2].ToString();

                flightList.Add(new clsFlight(Int32.Parse(flightID), Int32.Parse(flightNum), aircraftType));
             
            }
            return flightList;
            }
             catch (Exception ex)
             {
                 throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                     MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
             }
        }

        /// <summary>
        /// Creates a passenger list
        /// Uses sql to grab passenger information
        /// which is then added to the list
        /// </summary>
        /// <param name="flight"></param>
        /// <returns></returns>
        public List<clsPassenger> passengers(bool flight)
        {
            try
            {
                List<clsPassenger> passengerList = new List<clsPassenger>();

                int iRet = 0;   //Number of return values
                int iRet2 = 0;
                DataSet ds1; //Holds the return values
                DataSet ds2;

                if (flight)
                {
                    ds1 = db.ExecuteSQLStatement("SELECT * FROM Passenger pass INNER JOIN Flight_Passenger_Link  fpl ON pass.Passenger_ID = fpl.Passenger_ID WHERE fpl.Flight_ID = 1", ref iRet);
                    ds2 = db.ExecuteSQLStatement("SELECT Seat_Number FROM Flight_Passenger_Link  fpl WHERE fpl.Flight_ID = 1", ref iRet2);
                }
                else
                {
                    ds1 = db.ExecuteSQLStatement("SELECT * FROM Passenger pass INNER JOIN Flight_Passenger_Link  fpl ON pass.Passenger_ID = fpl.Passenger_ID WHERE fpl.Flight_ID = 2", ref iRet);
                    ds2 = db.ExecuteSQLStatement("SELECT Seat_Number FROM Flight_Passenger_Link  fpl WHERE fpl.Flight_ID = 2", ref iRet2);
                }

                // for passenger info
                for (int i = 0; i < iRet; i++)
                {
                    string passengerID = ds1.Tables[0].Rows[i][0].ToString();
                    string firstName = ds1.Tables[0].Rows[i][1].ToString();
                    string lastName = ds1.Tables[0].Rows[i][2].ToString();

                    passengerList.Add(new clsPassenger(Int32.Parse(passengerID), firstName, lastName));
                }

                //loops through the seats
                for (int i = 0; i < iRet2; i++)
                {
                    if (ds2.Tables[0].Rows[i][0] != null) //checks if null
                    {
                        //loops through the passenger
                        for (int j = 0; j < iRet; j++)
                        {
                            string passenger_id = ds1.Tables[0].Rows[j][0].ToString();
                            string seat_passenger_id = ds2.Tables[0].Rows[i][0].ToString();

                            //the passenger id matches the seat passenger id
                            if (passenger_id == seat_passenger_id)
                            {
                                passengerList[j].setpassSeats(ds2.Tables[0].Rows[i][2].ToString());
                            }
                        }

                    }
                }
                return passengerList;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
            
        }

       /// <summary>
       /// Handle the error.
       /// </summary>
       /// <param name="sClass">The class in which the error occurred in.</param>
       /// <param name="sMethod">The method in which the error occurred in.</param>
       private void HandleError(string sClass, string sMethod, string sMessage)
       {
           try
           {
               //Would write to a file or database here.
               MessageBox.Show(sClass + "." + sMethod + " -> " + sMessage);
           }
           catch (Exception ex)
           {
               System.IO.File.AppendAllText("C:\\Error.txt", Environment.NewLine +
                                            "HandleError Exception: " + ex.Message);
           }
       }
    }
}
