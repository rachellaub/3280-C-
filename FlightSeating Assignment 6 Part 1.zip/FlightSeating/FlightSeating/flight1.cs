﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;


namespace FlightSeating
{
    public partial class userControlFlight1 : UserControl
    {

        public userControlFlight1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// The user has clicked on a seat.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void Seat_Click(object sender, EventArgs e)
        {
            
        }

        /// <summary>
        /// Handle the error.
        /// </summary>
        /// <param name="sClass">The class in which the error occurred in.</param>
        /// <param name="sMethod">The method in which the error occurred in.</param>
        private void HandleError(string sClass, string sMethod, string sMessage)
        {
            try
            {
                //Would write to a file or database here.
                MessageBox.Show(sClass + "." + sMethod + " -> " + sMessage);
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllText("C:\\Error.txt", Environment.NewLine +
                                             "HandleError Exception: " + ex.Message);
            }
        }


    }
}
