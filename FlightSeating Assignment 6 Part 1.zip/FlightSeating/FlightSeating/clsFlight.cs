﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace FlightSeating
{
    class clsFlight
    {
        /// <summary>
        /// Flight ID
        /// </summary>
        int flightID;

        /// <summary>
        /// Flight number
        /// </summary>
        int flightNum;

        /// <summary>
        /// Flight aircraft type
        /// </summary>
        string aircraftType;

        public clsFlight(int fID, int fnum, string ftype)
        {
            flightID = fID;
            flightNum = fnum;
            aircraftType = ftype;
        }

        /// <summary>
        /// Overrides the format
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            try
            {
                return (flightNum.ToString() + " - " + aircraftType);
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
            
        }

        /// <summary>
        /// Handle the error.
        /// </summary>
        /// <param name="sClass">The class in which the error occurred in.</param>
        /// <param name="sMethod">The method in which the error occurred in.</param>
        private void HandleError(string sClass, string sMethod, string sMessage)
        {
            try
            {
                //Would write to a file or database here.
                MessageBox.Show(sClass + "." + sMethod + " -> " + sMessage);
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllText("C:\\Error.txt", Environment.NewLine +
                                             "HandleError Exception: " + ex.Message);
            }
        }
    }

}
