﻿namespace TicTacToe
{
    partial class TicTacToeGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl00 = new System.Windows.Forms.Label();
            this.lbl01 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Statistics = new System.Windows.Forms.GroupBox();
            this.tieScore = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.player1Score = new System.Windows.Forms.Label();
            this.player2Score = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.gameStatus = new System.Windows.Forms.GroupBox();
            this.startGame = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.lbl02 = new System.Windows.Forms.Label();
            this.lbl10 = new System.Windows.Forms.Label();
            this.lbl11 = new System.Windows.Forms.Label();
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl20 = new System.Windows.Forms.Label();
            this.lbl21 = new System.Windows.Forms.Label();
            this.lbl22 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.errorLabel = new System.Windows.Forms.Label();
            this.Statistics.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl00
            // 
            this.lbl00.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl00.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl00.Enabled = false;
            this.lbl00.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F);
            this.lbl00.Location = new System.Drawing.Point(103, 78);
            this.lbl00.Name = "lbl00";
            this.lbl00.Size = new System.Drawing.Size(339, 301);
            this.lbl00.TabIndex = 0;
            this.lbl00.Tag = "00";
            this.lbl00.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl00.Click += new System.EventHandler(this.Space_click);
            // 
            // lbl01
            // 
            this.lbl01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl01.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl01.Enabled = false;
            this.lbl01.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F);
            this.lbl01.Location = new System.Drawing.Point(479, 78);
            this.lbl01.Name = "lbl01";
            this.lbl01.Size = new System.Drawing.Size(339, 301);
            this.lbl01.TabIndex = 1;
            this.lbl01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl01.Click += new System.EventHandler(this.Space_click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(438, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 1030);
            this.label3.TabIndex = 2;
            this.label3.Text = "label3";
            // 
            // Statistics
            // 
            this.Statistics.Controls.Add(this.tieScore);
            this.Statistics.Controls.Add(this.label9);
            this.Statistics.Controls.Add(this.label8);
            this.Statistics.Controls.Add(this.player1Score);
            this.Statistics.Controls.Add(this.player2Score);
            this.Statistics.Controls.Add(this.label5);
            this.Statistics.Location = new System.Drawing.Point(1470, 133);
            this.Statistics.Name = "Statistics";
            this.Statistics.Size = new System.Drawing.Size(648, 519);
            this.Statistics.TabIndex = 3;
            this.Statistics.TabStop = false;
            this.Statistics.Text = "Statistics";
            // 
            // tieScore
            // 
            this.tieScore.AutoSize = true;
            this.tieScore.Location = new System.Drawing.Point(261, 246);
            this.tieScore.Name = "tieScore";
            this.tieScore.Size = new System.Drawing.Size(31, 32);
            this.tieScore.TabIndex = 6;
            this.tieScore.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(70, 115);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(191, 32);
            this.label9.TabIndex = 5;
            this.label9.Text = "Player 1 wins:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(70, 184);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(191, 32);
            this.label8.TabIndex = 4;
            this.label8.Text = "Player 2 wins:";
            // 
            // player1Score
            // 
            this.player1Score.AutoSize = true;
            this.player1Score.Location = new System.Drawing.Point(261, 115);
            this.player1Score.Name = "player1Score";
            this.player1Score.Size = new System.Drawing.Size(31, 32);
            this.player1Score.TabIndex = 3;
            this.player1Score.Text = "0";
            // 
            // player2Score
            // 
            this.player2Score.AutoSize = true;
            this.player2Score.Location = new System.Drawing.Point(261, 184);
            this.player2Score.Name = "player2Score";
            this.player2Score.Size = new System.Drawing.Size(31, 32);
            this.player2Score.TabIndex = 2;
            this.player2Score.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(192, 246);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 32);
            this.label5.TabIndex = 1;
            this.label5.Text = "Tie:";
            // 
            // gameStatus
            // 
            this.gameStatus.Location = new System.Drawing.Point(169, 1279);
            this.gameStatus.Name = "gameStatus";
            this.gameStatus.Size = new System.Drawing.Size(701, 217);
            this.gameStatus.TabIndex = 4;
            this.gameStatus.TabStop = false;
            this.gameStatus.Text = "Game Status";
            // 
            // startGame
            // 
            this.startGame.Location = new System.Drawing.Point(1275, 885);
            this.startGame.Name = "startGame";
            this.startGame.Size = new System.Drawing.Size(164, 81);
            this.startGame.TabIndex = 5;
            this.startGame.Text = "Start";
            this.startGame.UseVisualStyleBackColor = true;
            this.startGame.Click += new System.EventHandler(this.startGame_Click);
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(803, 78);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 1030);
            this.label6.TabIndex = 6;
            this.label6.Text = "label6";
            // 
            // lbl02
            // 
            this.lbl02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl02.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl02.Enabled = false;
            this.lbl02.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F);
            this.lbl02.Location = new System.Drawing.Point(846, 78);
            this.lbl02.Name = "lbl02";
            this.lbl02.Size = new System.Drawing.Size(339, 301);
            this.lbl02.TabIndex = 7;
            this.lbl02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl02.Click += new System.EventHandler(this.Space_click);
            // 
            // lbl10
            // 
            this.lbl10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl10.Enabled = false;
            this.lbl10.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F);
            this.lbl10.Location = new System.Drawing.Point(103, 426);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(339, 317);
            this.lbl10.TabIndex = 0;
            this.lbl10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl10.Click += new System.EventHandler(this.Space_click);
            // 
            // lbl11
            // 
            this.lbl11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl11.Enabled = false;
            this.lbl11.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F);
            this.lbl11.Location = new System.Drawing.Point(479, 426);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(339, 317);
            this.lbl11.TabIndex = 1;
            this.lbl11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl11.Click += new System.EventHandler(this.Space_click);
            // 
            // lbl12
            // 
            this.lbl12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl12.Enabled = false;
            this.lbl12.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F);
            this.lbl12.Location = new System.Drawing.Point(846, 426);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(339, 317);
            this.lbl12.TabIndex = 7;
            this.lbl12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl12.Click += new System.EventHandler(this.Space_click);
            // 
            // lbl20
            // 
            this.lbl20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl20.Enabled = false;
            this.lbl20.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F);
            this.lbl20.Location = new System.Drawing.Point(103, 791);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(339, 317);
            this.lbl20.TabIndex = 0;
            this.lbl20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl20.Click += new System.EventHandler(this.Space_click);
            // 
            // lbl21
            // 
            this.lbl21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl21.Enabled = false;
            this.lbl21.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F);
            this.lbl21.Location = new System.Drawing.Point(479, 791);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(325, 317);
            this.lbl21.TabIndex = 1;
            this.lbl21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl21.Click += new System.EventHandler(this.Space_click);
            // 
            // lbl22
            // 
            this.lbl22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl22.Enabled = false;
            this.lbl22.Font = new System.Drawing.Font("Microsoft Sans Serif", 90F);
            this.lbl22.Location = new System.Drawing.Point(846, 791);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(339, 317);
            this.lbl22.TabIndex = 7;
            this.lbl22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl22.Click += new System.EventHandler(this.Space_click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(103, 743);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1082, 48);
            this.label1.TabIndex = 8;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(103, 379);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1082, 47);
            this.label2.TabIndex = 9;
            this.label2.Text = "label2";
            // 
            // errorLabel
            // 
            this.errorLabel.AutoSize = true;
            this.errorLabel.Location = new System.Drawing.Point(1540, 897);
            this.errorLabel.Name = "errorLabel";
            this.errorLabel.Size = new System.Drawing.Size(0, 32);
            this.errorLabel.TabIndex = 10;
            // 
            // TicTacToeGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(2472, 1531);
            this.Controls.Add(this.errorLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl22);
            this.Controls.Add(this.lbl12);
            this.Controls.Add(this.lbl02);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.startGame);
            this.Controls.Add(this.gameStatus);
            this.Controls.Add(this.Statistics);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbl21);
            this.Controls.Add(this.lbl20);
            this.Controls.Add(this.lbl11);
            this.Controls.Add(this.lbl10);
            this.Controls.Add(this.lbl01);
            this.Controls.Add(this.lbl00);
            this.Name = "TicTacToeGame";
            this.Text = "Tic Tac Toe";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Statistics.ResumeLayout(false);
            this.Statistics.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl00;
        private System.Windows.Forms.Label lbl01;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox Statistics;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox gameStatus;
        private System.Windows.Forms.Button startGame;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbl02;
        private System.Windows.Forms.Label lbl10;
        private System.Windows.Forms.Label lbl11;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl20;
        private System.Windows.Forms.Label lbl21;
        private System.Windows.Forms.Label lbl22;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label errorLabel;
        private System.Windows.Forms.Label tieScore;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label player1Score;
        private System.Windows.Forms.Label player2Score;
    }
}

