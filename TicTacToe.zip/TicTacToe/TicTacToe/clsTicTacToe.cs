﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe
{
    public class clsTicTacToe
    {
        /// <summary>
        /// saBoard is the multidimensional array instatiated in Form1
        /// </summary>
        public string[,] saBoard;

        /// <summary>
        /// keeps the score of player 1
        /// </summary>
        public int iPlayer1Wins = 0;

        /// <summary>
        /// keeps the score of player 2
        /// </summary>
        public int iPlayer2Wins = 0;

        /// <summary>
        /// keeps the score for ties
        /// </summary>
        public int iTies = 0;

        /// <summary>
        /// Produces the string for which player won
        /// </summary>
        public string whichPlayer = "";

        /// <summary>
        /// keeps tracks of where the winning move is
        /// </summary>
        public WinningMove eWinningMove; 


        /// <summary>
        /// defines the ways for wins
        /// </summary>
        public enum WinningMove
        {
            Row1,
            Row2,
            Row3,
            Col1,
            Col2,
            Col3,
            Diag1, 
            Diag2
        }

        /// <summary>
        /// defines where the winning move is located
        /// </summary>
        public bool isWinningMove()
        {
            //this is where loop through the array
            //then returns the winning move
            if (saBoard[0, 0] == "X" && saBoard[0, 1] == "X" && saBoard[0, 2] == "X")
            {
                eWinningMove = WinningMove.Row1;//calls the winning move
                //Player 1 wins
                iPlayer1Wins++;
                whichPlayer = "Player 1 wins";
                return true;
            }
            else if (saBoard[1, 0] == "X" && saBoard[1, 1] == "X" && saBoard[1, 2] == "X")
            {
                eWinningMove = WinningMove.Row2;//calls the winning move
                //Player 1 wins
                iPlayer1Wins++;
                whichPlayer = "Player 1 wins";
                return true;
            }
            else if (saBoard[2, 0] == "X" && saBoard[2, 1] == "X" && saBoard[2, 2] == "X")
            {
                eWinningMove = WinningMove.Row3;//calls the winning move
                //Player 1 wins
                iPlayer1Wins++;
                whichPlayer = "Player 1 wins";
                return true;
            }
            else if (saBoard[0, 0] == "X" && saBoard[1, 1] == "X" && saBoard[2, 2] == "X")
            {
                eWinningMove = WinningMove.Diag1;//calls the winning move
                //Player 1 wins
                iPlayer1Wins++;
                whichPlayer = "Player 1 wins";
                return true;
            }
            else if (saBoard[0, 2] == "X" && saBoard[1, 1] == "X" && saBoard[2, 0] == "X")
            {
                eWinningMove = WinningMove.Diag2;//calls the winning move
                //Player 1 wins
                iPlayer1Wins++;
                whichPlayer = "Player 1 wins";
                return true;
            }
            else if (saBoard[0, 0] == "X" && saBoard[1, 0] == "X" && saBoard[2, 0] == "X")
            {
                eWinningMove = WinningMove.Col1;//calls the winning move
                //Player 1 wins
                iPlayer1Wins++;
                whichPlayer = "Player 1 wins";
                return true;
            }
            else if (saBoard[0, 1] == "X" && saBoard[1, 1] == "X" && saBoard[2, 1] == "X")
            {
                eWinningMove = WinningMove.Col2;//calls the winning move
                //Player 1 wins
                iPlayer1Wins++;
                whichPlayer = "Player 1 wins";
                return true;
            }
            else if (saBoard[0, 2] == "X" && saBoard[1, 2] == "X" && saBoard[2, 2] == "X")
            {
                eWinningMove = WinningMove.Col3;//calls the winning move
                //Player 1 wins
                iPlayer1Wins++;
                whichPlayer = "Player 1 wins";
                return true;
            }
            else if (saBoard[0, 0] == "O" && saBoard[0, 1] == "O" && saBoard[0, 2] == "O")
            {
                eWinningMove = WinningMove.Row1;//calls the winning move
                //Player 2 wins
                iPlayer2Wins++;
                whichPlayer = "Player 2 wins";
                return true;
            }
            else if (saBoard[1, 0] == "O" && saBoard[1, 1] == "O" && saBoard[1, 2] == "O")
            {
                eWinningMove = WinningMove.Row2;//calls the winning move
                //Player 2 wins
                iPlayer2Wins++;
                whichPlayer = "Player 2 wins";
                return true;
            }
            else if (saBoard[2, 0] == "O" && saBoard[2, 1] == "O" && saBoard[2, 2] == "O")
            {
                eWinningMove = WinningMove.Row3;//calls the winning move
                //Player 2 wins
                iPlayer2Wins++;
                whichPlayer = "Player 2 wins";
                return true;
            }
            else if (saBoard[0, 0] == "O" && saBoard[1, 1] == "O" && saBoard[2, 2] == "O")
            {
                eWinningMove = WinningMove.Diag1;//calls the winning move
                //Player 2 wins
                iPlayer2Wins++;
                whichPlayer = "Player 2 wins";
                return true;
            }
            else if (saBoard[0, 2] == "O" && saBoard[1, 1] == "O" && saBoard[2, 0] == "O")
            {
                eWinningMove = WinningMove.Diag2;//calls the winning move
                //Player 2 wins
                iPlayer2Wins++;
                whichPlayer = "Player 2 wins";
                return true;
            }
            else if (saBoard[0, 0] == "O" && saBoard[1, 0] == "O" && saBoard[2, 0] == "O")
            {
                eWinningMove = WinningMove.Col1;//calls the winning move
                //Player 2 wins
                iPlayer2Wins++;
                whichPlayer = "Player 2 wins";
                return true;
            }
            else if (saBoard[0, 1] == "O" && saBoard[1, 1] == "O" && saBoard[2, 1] == "O")
            {
                eWinningMove = WinningMove.Col2;//calls the winning move
                //Player 2 wins
                iPlayer2Wins++;
                whichPlayer = "Player 2 wins";
                return true;
            }
            else if (saBoard[0, 2] == "O" && saBoard[1, 2] == "O" && saBoard[2, 2] == "O")
            {
                eWinningMove = WinningMove.Col3;//calls the winning move
                //Player 2 wins
                iPlayer2Wins++;
                whichPlayer = "Player 2 wins";
                return true;
            }
            
            return false;
        }

        /// <summary>
        /// determines if there is a tie
        /// </summary>
        /// <returns></returns>
        public bool IsTie()
        {
            //loops through away to see if blank
            //if none blank than it is a tie

            for (int row = 0; row < saBoard.GetLength(0); row++) //loops through rows
            {
                //loops through columns of current row
                for (int col = 0; col < saBoard.GetLength(1); col++)
                {
                    if (saBoard[row, col] == " ")
                    {
                        return false;
                    }
                }
            }
            whichPlayer = "Player Tie";
            iTies++;
            return true;
        }
    }
}
