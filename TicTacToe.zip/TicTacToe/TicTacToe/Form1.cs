﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicTacToe
{
    public partial class TicTacToeGame : Form
    {
        /// <summary>
        /// initilizes the clsTicTacToe class
        /// </summary>
        clsTicTacToe clsTicTac;

        /// <summary>
        /// defines whether the game is started
        /// </summary>
        bool bIsGameStarted;

        /// <summary>
        /// array that keeps track of the board
        /// </summary>
        string[,] saBoard;

        /// <summary>
        /// keeps track of which player it is
        /// </summary>
        bool playerTurn = true;

        /// <summary>
        /// Initializes the saBoard and says that the game has not been started
        /// </summary>
        public TicTacToeGame()
        {
            InitializeComponent();

            clsTicTac = new clsTicTacToe();
            clsTicTac.saBoard = new string[3,3]; 
            bIsGameStarted = false;
        }

        /// <summary>
        /// starts the game. Resets the board and allows user to click on board
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void startGame_Click(object sender, EventArgs e)
        {
            bIsGameStarted = true;
            resetLabels(); //resets labels
            resetColors(); //resets colors
            resetVariables(); //resets the variables
            //enables all the labels on the board
            lbl00.Enabled = true;
            lbl01.Enabled = true;
            lbl02.Enabled = true;
            lbl10.Enabled = true;
            lbl11.Enabled = true;
            lbl12.Enabled = true;
            lbl20.Enabled = true;
            lbl21.Enabled = true;
            lbl22.Enabled = true;
            
            
        }

        /// <summary>
        /// Called when label on board is clicked
        /// It puts letters on the board
        /// Calls the isWinningMove and isTie from clsTicTacToe
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Space_click(object sender, EventArgs e)
        {

            //resetError Label
            errorLabel.Text = "";
            //get board working switching turns 
            
            //checks if the game is started
            if (bIsGameStarted == true) {
                //grabs the label
                Label MyLabel = (Label)sender;
                //if the label is blank
                if (MyLabel.Text == "X" || MyLabel.Text == "O") {
                    //error message that box has already been taken
                    errorLabel.Text = "That space has already been taken. Pick another one";
                }
                else {

                    if (playerTurn == true) {
                        MyLabel.Text = "X"; //if player one then set label to X  
                    }
                    else {
                        MyLabel.Text = "O"; //if player two then set label to O
                    }
                }
                loadGameboard(); //loads the gameboard
                playerTurn = !playerTurn; //switches which players turn
            }
            else {
                //message to the error label
                errorLabel.Text = "Start button has not been pressed!";
            }

            if (clsTicTac.isWinningMove())
            {
                //highlight the winning move and display the scores
                highlightWinningMove();
                DisplayScores();
                disableBoard();
            }
            else if (clsTicTac.IsTie())
            {
                highlightTie();
                DisplayScores();
            }  
        }

        private void highlightTie()
        {
            lbl00.BackColor = Color.FromArgb(189, 189, 255);
            lbl01.BackColor = Color.FromArgb(189, 189, 255);
            lbl02.BackColor = Color.FromArgb(189, 189, 255);
            lbl10.BackColor = Color.FromArgb(189, 189, 255);
            lbl11.BackColor = Color.FromArgb(189, 189, 255);
            lbl12.BackColor = Color.FromArgb(189, 189, 255);
            lbl20.BackColor = Color.FromArgb(189, 189, 255);
            lbl21.BackColor = Color.FromArgb(189, 189, 255);
            lbl22.BackColor = Color.FromArgb(189, 189, 255);
        }

        /// <summary>
        /// loads gameboard
        /// </summary>
        private void loadGameboard()
        {
            clsTicTac.saBoard[0, 0] = lbl00.Text;
            clsTicTac.saBoard[0, 1] = lbl01.Text;
            clsTicTac.saBoard[0, 2] = lbl02.Text;
            clsTicTac.saBoard[1, 0] = lbl10.Text;
            clsTicTac.saBoard[1, 1] = lbl11.Text;
            clsTicTac.saBoard[1, 2] = lbl12.Text;
            clsTicTac.saBoard[2, 0] = lbl20.Text;
            clsTicTac.saBoard[2, 1] = lbl21.Text;
            clsTicTac.saBoard[2, 2] = lbl22.Text;


        }

        /// <summary>
        /// Displays the scores
        /// </summary>
        private void DisplayScores()
        {
            player1Score.Text = clsTicTac.iPlayer1Wins.ToString();
            player2Score.Text = clsTicTac.iPlayer2Wins.ToString();
            tieScore.Text = clsTicTac.iTies.ToString();
            gameStatus.Text = clsTicTac.whichPlayer;
        }

        /// <summary>
        /// highlights the winning move
        /// </summary>
        private void highlightWinningMove()
        {
            //grabs winning move and highlights rows
            //use case statement

            switch (clsTicTac.eWinningMove)
            {
                case clsTicTacToe.WinningMove.Row1:
                    lbl00.BackColor = Color.FromArgb(255, 189, 255);
                    lbl01.BackColor = Color.FromArgb(255, 189, 255);
                    lbl02.BackColor = Color.FromArgb(255, 189, 255);
                    break;
                case clsTicTacToe.WinningMove.Row2:
                    lbl10.BackColor = Color.FromArgb(255, 189, 255);
                    lbl11.BackColor = Color.FromArgb(255, 189, 255);
                    lbl12.BackColor = Color.FromArgb(255, 189, 255);
                    break;
                case clsTicTacToe.WinningMove.Row3:
                    lbl20.BackColor = Color.FromArgb(255, 189, 255);
                    lbl21.BackColor = Color.FromArgb(255, 189, 255);
                    lbl22.BackColor = Color.FromArgb(255, 189, 255);
                    break;
                case clsTicTacToe.WinningMove.Col1:
                    lbl00.BackColor = Color.FromArgb(255, 189, 255);
                    lbl10.BackColor = Color.FromArgb(255, 189, 255);
                    lbl20.BackColor = Color.FromArgb(255, 189, 255);
                    break;
                case clsTicTacToe.WinningMove.Col2:
                    lbl01.BackColor = Color.FromArgb(255, 189, 255);
                    lbl11.BackColor = Color.FromArgb(255, 189, 255);
                    lbl21.BackColor = Color.FromArgb(255, 189, 255);
                    break;
                case clsTicTacToe.WinningMove.Col3:
                    lbl02.BackColor = Color.FromArgb(255, 189, 255);
                    lbl12.BackColor = Color.FromArgb(255, 189, 255);
                    lbl22.BackColor = Color.FromArgb(255, 189, 255);
                    break;
                case clsTicTacToe.WinningMove.Diag1:
                    lbl00.BackColor = Color.FromArgb(255, 189, 255);
                    lbl11.BackColor = Color.FromArgb(255, 189, 255);
                    lbl22.BackColor = Color.FromArgb(255, 189, 255);
                    break;
                case clsTicTacToe.WinningMove.Diag2:
                    lbl02.BackColor = Color.FromArgb(255, 189, 255);
                    lbl11.BackColor = Color.FromArgb(255, 189, 255);
                    lbl20.BackColor = Color.FromArgb(255, 189, 255);
                    break;

            }
        }

        /// <summary>
        /// once a player has won the board is disabled
        /// </summary>
        private void disableBoard()
        {
            lbl00.Enabled = false;
            lbl01.Enabled = false;
            lbl02.Enabled = false;
            lbl10.Enabled = false;
            lbl11.Enabled = false;
            lbl12.Enabled = false;
            lbl20.Enabled = false;
            lbl21.Enabled = false;
            lbl22.Enabled = false;
        }

        /// <summary>
        /// resets the labels
        /// </summary>
        private void resetLabels()
        {
            errorLabel.Text = "";
            lbl00.Text = " ";
            lbl01.Text = " ";
            lbl02.Text = " ";
            lbl10.Text = " ";
            lbl11.Text = " ";
            lbl12.Text = " ";
            lbl20.Text = " ";
            lbl21.Text = " ";
            lbl22.Text = " ";
        }

        /// <summary>
        /// resets colors
        /// </summary>
        private void resetColors()
        {
            //resets all the back color of labels
            lbl00.BackColor = Color.FromArgb(192, 255, 192);
            lbl01.BackColor = Color.FromArgb(192, 255, 192);
            lbl02.BackColor = Color.FromArgb(192, 255, 192);
            lbl10.BackColor = Color.FromArgb(192, 255, 192);
            lbl11.BackColor = Color.FromArgb(192, 255, 192);
            lbl12.BackColor = Color.FromArgb(192, 255, 192);
            lbl20.BackColor = Color.FromArgb(192, 255, 192);
            lbl21.BackColor = Color.FromArgb(192, 255, 192);
            lbl22.BackColor = Color.FromArgb(192, 255, 192);
           
        }

        /// <summary>
        /// resets variables
        /// </summary>
        private void resetVariables()
        {
            playerTurn = true;
            gameStatus.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
