﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace A2
{
    public partial class dieGame : Form
    {
        int numPlay = 0; //keeps track of how many games
        int numWon = 0; //keeps track of games won
        int numLost = 0; //keeps tracks of games lost
        int[] frequency = { 0, 0, 0, 0, 0, 0 }; //in
        int[] freqGuesses = { 0, 0, 0, 0, 0, 0 };
        double[] percent = { 0, 0, 0, 0, 0, 0 };
        double freqSum = 1;

        public dieGame()
        {
            InitializeComponent();
        }

        /// <summary>
        /// This method is called when the roll button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void roll_Click(object sender, EventArgs e)
        {
            int guess = 0; //users input
            int result; //helps get user input
            Random randomNum = new Random(); //random number generator
            int face = 0; //stores each random integer generated.

            //extracting the number from the playerGuess textbox
            if (Int32.TryParse(playerGuess.Text, out result) == true)
            {
                guess = result;
            }

            //while loop to calculate everything
            while (guess >= 1 && guess <= 6)
            {
                //generates the die images
                for (int i = 1; i < 7; i++)
                {
                    face = randomNum.Next(1, 7); //choses random numbers 
                    dieImage.Image = Image.FromFile("die" + face + ".gif"); //randNums correspond to die faces 
                    dieImage.Refresh();
                    Thread.Sleep(300);
                }

                //Win
                if (face == guess)
                {
                    check.Text = "You won!";
                    numWon++; //increments count for numWon
                    numLostLabel.Text = numLost.ToString();//prints to label
                    numWonLabel.Text = numWon.ToString();//prints to label
                    playerGuess.Text = "";
                    break;
                }
                else if (face != guess)
                {
                    check.Text = "You lost.";
                    numLost++; //increments count for numLost
                    numLostLabel.Text = numLost.ToString();//prints to label
                    numWonLabel.Text = numWon.ToString();//prints to label
                    playerGuess.Text = "";
                    break;

                }

            }
            if (guess < 1 || guess > 6)
            {
                check.Text = "Enter a valid number between 1 and 6.";
                numPlayLabel.Text = numPlay.ToString();//prints to label
                numWonLabel.Text = numWon.ToString();//prints to label
                numLostLabel.Text = numLost.ToString();//prints to label

            }
            else //problem here won't increase from 1
            {
                numPlay++; //increments the number of times played
                numPlayLabel.Text = numPlay.ToString(); //prints to label

            }

            //adds values to frequency
            if (face == 1)
            {
                frequency[0]++;
            }
            else if (face == 2)
            {
                frequency[1]++;
            }
            else if (face == 3)
            {
                frequency[2]++;
            }
            else if (face == 4)
            {
                frequency[3]++;
            }
            else if (face == 5)
            {
                frequency[4]++;
            }
            else if (face == 6)
            {
                frequency[5]++;
            }


            //adds value to freqGuesses
            if (guess == 1)
            {
                freqGuesses[0]++;
            }
            else if (guess == 2)
            {
                freqGuesses[1]++;
            }
            else if (guess == 3)
            {
                freqGuesses[2]++;
            }
            else if (guess == 4)
            {
                freqGuesses[3]++;
            }
            else if (guess == 5)
            {
                freqGuesses[4]++;
            }
            else if (guess == 6)
            {
                freqGuesses[5]++;
            }

            //calculates percent for each face
            freqSum = frequency[0] + frequency[1] + frequency[2] + frequency[3] + frequency[4] + frequency[5];
            percent[0] = (frequency[0] / freqSum) * 100;
            percent[1] = (frequency[1] / freqSum) * 100;
            percent[2] = (frequency[2] / freqSum) * 100;
            percent[3] = (frequency[3] / freqSum) * 100;
            percent[4] = (frequency[4] / freqSum) * 100;
            percent[5] = (frequency[5] / freqSum) * 100;

            //output for rich text box 
            stats.Text = ""; //resets text box
            stats.Text += "Face\tFrequency\tPercent\t\tNumber Of Times Guessed\n";
            stats.Text += "1\t" + frequency[0] + "\t\t" + string.Format("{0:0.00}", percent[0]) + "%\t\t" + freqGuesses[0] + "\n";
            stats.Text += "2\t" + frequency[1] + "\t\t" + string.Format("{0:0.00}", percent[1]) + "%\t\t" + freqGuesses[1] + "\n";
            stats.Text += "3\t" + frequency[2] + "\t\t" + string.Format("{0:0.00}", percent[2]) + "%\t\t" + freqGuesses[2] + "\n";
            stats.Text += "4\t" + frequency[3] + "\t\t" + string.Format("{0:0.00}", percent[3]) + "%\t\t" + freqGuesses[3] + "\n";
            stats.Text += "5\t" + frequency[4] + "\t\t" + string.Format("{0:0.00}", percent[4]) + "%\t\t" + freqGuesses[4] + "\n";
            stats.Text += "6\t" + frequency[5] + "\t\t" + string.Format("{0:0.00}", percent[5]) + "%\t\t" + freqGuesses[5] + "\n";


        }

        /// <summary>
        /// Reset button clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Reset_Click(object sender, EventArgs e)
        {
            numPlay = 0; //resets number played
            numWon = 0; //resets number won
            numLost = 0; //resets number lost
            numPlayLabel.Text = numPlay.ToString();
            numWonLabel.Text = numWon.ToString();
            numLostLabel.Text = numLost.ToString();
            check.Text = "";
            dieImage.Image = Image.FromFile("die1.gif");
            stats.Text = ""; //resets rich text box
            percent[0] = 0; //resets percent
            percent[1] = 0; 
            percent[2] = 0; 
            percent[3] = 0; 
            percent[4] = 0; 
            percent[5] = 0; 
            frequency[0] = 0; //resets frequency
            frequency[1] = 0; 
            frequency[2] = 0; 
            frequency[3] = 0; 
            frequency[4] = 0; 
            frequency[5] = 0; 
            freqGuesses[0] = 0; //resets freqGuesses
            freqGuesses[1] = 0; 
            freqGuesses[2] = 0; 
            freqGuesses[3] = 0; 
            freqGuesses[4] = 0; 
            freqGuesses[5] = 0; 
        }

    }
}
