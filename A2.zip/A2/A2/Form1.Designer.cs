﻿namespace A2
{
    partial class dieGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.numPlayLabel = new System.Windows.Forms.Label();
            this.numWonLabel = new System.Windows.Forms.Label();
            this.numLostLabel = new System.Windows.Forms.Label();
            this.stats = new System.Windows.Forms.RichTextBox();
            this.dieImage = new System.Windows.Forms.PictureBox();
            this.playerGuess = new System.Windows.Forms.TextBox();
            this.roll = new System.Windows.Forms.Button();
            this.Reset = new System.Windows.Forms.Button();
            this.check = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dieImage)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(123, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Game Info";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(123, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(321, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Number of times played:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(123, 247);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(288, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Number of times won:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(123, 301);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(281, 32);
            this.label4.TabIndex = 3;
            this.label4.Text = "Number of times lost:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(129, 410);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(302, 32);
            this.label5.TabIndex = 4;
            this.label5.Text = "Enter your guess (1-6):";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(290, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 32);
            this.label6.TabIndex = 6;
            this.label6.Text = "label6";
            // 
            // numPlayLabel
            // 
            this.numPlayLabel.AutoSize = true;
            this.numPlayLabel.Location = new System.Drawing.Point(450, 186);
            this.numPlayLabel.Name = "numPlayLabel";
            this.numPlayLabel.Size = new System.Drawing.Size(93, 32);
            this.numPlayLabel.TabIndex = 7;
            this.numPlayLabel.Text = "label7";
            // 
            // numWonLabel
            // 
            this.numWonLabel.AutoSize = true;
            this.numWonLabel.Location = new System.Drawing.Point(450, 247);
            this.numWonLabel.Name = "numWonLabel";
            this.numWonLabel.Size = new System.Drawing.Size(93, 32);
            this.numWonLabel.TabIndex = 8;
            this.numWonLabel.Text = "label8";
            // 
            // numLostLabel
            // 
            this.numLostLabel.AutoSize = true;
            this.numLostLabel.Location = new System.Drawing.Point(435, 301);
            this.numLostLabel.Name = "numLostLabel";
            this.numLostLabel.Size = new System.Drawing.Size(93, 32);
            this.numLostLabel.TabIndex = 9;
            this.numLostLabel.Text = "label9";
            // 
            // stats
            // 
            this.stats.Location = new System.Drawing.Point(135, 675);
            this.stats.Name = "stats";
            this.stats.Size = new System.Drawing.Size(1170, 423);
            this.stats.TabIndex = 13;
            this.stats.Text = "";
            // 
            // dieImage
            // 
            this.dieImage.Location = new System.Drawing.Point(888, 120);
            this.dieImage.Name = "dieImage";
            this.dieImage.Size = new System.Drawing.Size(317, 235);
            this.dieImage.TabIndex = 14;
            this.dieImage.TabStop = false;
            // 
            // playerGuess
            // 
            this.playerGuess.Location = new System.Drawing.Point(443, 410);
            this.playerGuess.Name = "playerGuess";
            this.playerGuess.Size = new System.Drawing.Size(139, 38);
            this.playerGuess.TabIndex = 15;
            // 
            // roll
            // 
            this.roll.Location = new System.Drawing.Point(441, 493);
            this.roll.Name = "roll";
            this.roll.Size = new System.Drawing.Size(161, 63);
            this.roll.TabIndex = 16;
            this.roll.Text = "Roll";
            this.roll.UseVisualStyleBackColor = true;
            this.roll.Click += new System.EventHandler(this.roll_Click);
            // 
            // Reset
            // 
            this.Reset.Location = new System.Drawing.Point(443, 585);
            this.Reset.Name = "Reset";
            this.Reset.Size = new System.Drawing.Size(161, 70);
            this.Reset.TabIndex = 17;
            this.Reset.Text = "Reset";
            this.Reset.UseVisualStyleBackColor = true;
            this.Reset.Click += new System.EventHandler(this.Reset_Click);
            // 
            // check
            // 
            this.check.AutoSize = true;
            this.check.Location = new System.Drawing.Point(649, 410);
            this.check.Name = "check";
            this.check.Size = new System.Drawing.Size(109, 32);
            this.check.TabIndex = 18;
            this.check.Text = "label10";
            // 
            // dieGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1543, 1204);
            this.Controls.Add(this.check);
            this.Controls.Add(this.Reset);
            this.Controls.Add(this.roll);
            this.Controls.Add(this.playerGuess);
            this.Controls.Add(this.dieImage);
            this.Controls.Add(this.stats);
            this.Controls.Add(this.numLostLabel);
            this.Controls.Add(this.numWonLabel);
            this.Controls.Add(this.numPlayLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "dieGame";
            this.Text = "Dice Guess Game";
            ((System.ComponentModel.ISupportInitialize)(this.dieImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label numPlayLabel;
        private System.Windows.Forms.Label numWonLabel;
        private System.Windows.Forms.Label numLostLabel;
        private System.Windows.Forms.RichTextBox stats;
        private System.Windows.Forms.PictureBox dieImage;
        private System.Windows.Forms.TextBox playerGuess;
        private System.Windows.Forms.Button roll;
        private System.Windows.Forms.Button Reset;
        private System.Windows.Forms.Label check;
    }
}

