﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Start_A3
{
    public partial class Scores : Form
    {
        //global variables
        /// <summary>
        /// initializes single-dimensional array for studentNames
        /// </summary>
        string[] name; 

        /// <summary>
        /// initializes multi-dimensional array for assignmentScores
        /// </summary>
        int[,] assignments;

        /// <summary>
        /// user input for students
        /// </summary>
        int numStud = 0;

        ///<summary>
        ///user input for assingments
        ///</summary>
        int numAssign = 0; 

        /// <summary>
        /// position turns into name[0]
        /// </summary>
        string position; 

        /// <summary>
        /// max value in the array
        /// </summary>
        int last; 

        /// <summary>
        /// helps with name array
        /// </summary>
        int num = 0; 

        /// <summary>
        /// intializes average
        /// </summary>
        int avg = 0; 

        /// <summary>
        /// intializes grade
        /// </summary>
        string grade = ""; 

        public Scores()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Submit class which creates arrays and adds values
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void submit_Click(object sender, EventArgs e)
        {
            //variables for getting info from textboxes
            ///<summary>
            ///helps get numStudents
            ///</summary>
           int students; 


            ///<summary>
           ///helps get numAssignments
           ///</summary>
           int assignment; 


            ///<summary>
            ///extracting the number from the numStudents textbox
            ///</summary>
            if (Int32.TryParse(numStudents.Text, out students) == true)
            {
                numStud = students; //assigns the number of students
                last = numStud - 1;
            }

            ///<summary>
            ///extracting the number from the numAssignments textbox
            ///</summary>
            if (Int32.TryParse(numAssignments.Text, out assignment) == true)
            {
                numAssign = assignment; //assigns the number of assignments
            }

            ///<summary>
            ///checks if input is correct if it is then it creates the array, fills it, and updates labels
            ///</summary>
            if (numStud > 10 && numAssign > 99) //numbers out of bounds for scenario
            {
                errorMessage.Text = "Error! Student# 10 or less and Assignment# 99 or less.";
            }
            else 
            {
                //create array length and widths.
                ///<summary>
                ///name array is number of students long
                ///</summary>
                name = new string[numStud]; 

                ///<summary>
                ///assignments array is number of students long by number assignments
                ///</summary>
                assignments = new int[numStud, numAssign]; 

                // fill arrays
                fillArrayName(name); //fills name array
                fillArrayAssignment(assignments); //fills student array

                //enable commands
                enableCommands();

                //update dynamic assignment and studentNames label
                assignmentNumLabel.Text = "Enter Assignment number(1-" + numAssign + "):";
                updateLabel();
            }

           
        }//end Submit Click

        /// <summary>
        /// updates the Labels for student names
        /// </summary>
        private void updateLabel()
        {
            studentNameLabel.Text = position + ":";
        } //ends updateLabels


        /// <summary>
        /// enable commands once values are correct
        /// </summary>
        private void enableCommands() 
        {
            firstStudent.Enabled = true; //Enables firstStudent
            prevStudent.Enabled = true; //Enables prevStudent
            nextStudent.Enabled = true; //Enables nextStudent
            lastStudent.Enabled = true; //Enables lastStudent
            studentName.Enabled = true; //Enables studentName
            saveName.Enabled = true; //Enables saveName
            assignmentNum.Enabled = true; //Enables assignmentNum
            assignmentScore.Enabled = true; //Enables assignmentScore
            saveScore.Enabled = true; //Enables saveScore
            reset.Enabled = true; //Enables reset
            displayScores.Enabled = true; //Enables displayScores

        }//end enableCommands

        /// <summary>
        /// fillArrayName puts values into the name array
        /// </summary>
        /// <param name="name"></param>
        private void fillArrayName(string[] name)
        { 
            //fill name array with student position
            for (int i = 0; i < name.Length; i++)
            {
                int num = i + 1;
                name[i] = "Student #" + num; //for position 0>1, position 1>2, etc.
            }//end for loop
            position = name[0]; //sets the position in the array to 0
        }//end fillArrayName

        /// <summary>
        /// fills all assignments with the value 0
        /// </summary>
        /// <param name="assignments"></param>
        private void fillArrayAssignment(int[,] assignments)
        {
            //fill assignments array with assignment scores
            for (int row = 0; row < assignments.GetLength(0); row++) //loops through rows
            {
                //loops through columns of current row
                for (int col = 0; col < assignments.GetLength(1); col++)
                {
                    assignments[row, col] = 0; //sets all assignment values to 0.
                }
            }
 
        }

        /// <summary>
        /// moves the position of the array to the first student
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void firstStudent_Click(object sender, EventArgs e)
        {
            errorMessage.Text = "";
            num = 0;
            position = name[0];
            updateLabel(); //updates name of student
        }//end firstStudent_Click

        /// <summary>
        /// move the position of the array to the last student
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lastStudent_Click(object sender, EventArgs e)
        {
            errorMessage.Text = "";
            num = last; //num equals the amount of students
            position = name[last]; //sets position to the edge of the array
            updateLabel(); //updates name of student
        }//end lastStudent_Click

        /// <summary>
        /// move the position of the array to the next student
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void nextStudent_Click(object sender, EventArgs e)
        {
            errorMessage.Text = "";
           
            //stops array at the end
            if (num == last) 
            {   //disables nextStuden button
                errorMessage.Text = "At last index.Stop";
            }
            else
            {
                num += 1; //changes to num to the next position
                //prints out the student num/name
                position = name[num];
                updateLabel();
            }
              
            
        }//end nextStudent_click

        /// <summary>
        /// move the position of the array to the previous student
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void prevStudent_Click(object sender, EventArgs e)
        {
            errorMessage.Text = "";
           
            //stop array at the end
            if (num == 0)
            {
                errorMessage.Text = "At the first index. Stop!";
            }
            else
            {
                num -= 1;//changes num to the previous position
                //prints out the student num/name
                position = name[num];
                updateLabel();
            }

               
            
        }

        /// <summary>
        /// saves name from the array
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveName_Click(object sender, EventArgs e)
        {
            //grabs student name from text box
            string studName = studentName.Text;
            //set array position to the name
            position = name[num]; //changes the position for the label
            name[num] = studName; //sets the certain position in the array to the name
            updateLabel(); //updates the name Label
            studentName.Text = ""; //clears name from textbox
       

        }

        /// <summary>
        /// saves the score to the array
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveScore_Click(object sender, EventArgs e)
        {
            int assignNum;//helps with assignment number
            int numAssignment =0; //assignment number
            int assignScore; //helps with assignment score
            int score = 0;//assignment score

            //gets the assignment number
            if (Int32.TryParse(assignmentNum.Text, out assignNum) == true)
            {
                numAssignment= assignNum; //assigns the number of students
               
            }
            //gets the assignment score
            if (Int32.TryParse(assignmentScore.Text, out assignScore) == true)
            {
                score = assignScore; //assigns score value
                
            }

            ///<summary>
            ///validates user input for score
            ///</summary>
            if (score < 0 || score > 100)
            {
                //checks if assignment number exists
                if (numAssignment == 0 || numAssignment > numAssign)
                {
                    errorMessage.Text = "Please enter a score between 0 and 100 & enter a valid assignment number.";
                }
                else
                {
                    errorMessage.Text = "Please enter a score between 0 and 100.";
                }
            }
            else
            {
                assignments[num, numAssignment - 1] = score; //places the score in the array
                assignmentNum.Text = ""; // clears assignment number from textbox
                assignmentScore.Text = ""; //clears assignment score from textbox
            }

        }

        /// <summary>
        /// calculates the average score per column
        /// </summary>
        /// <param name="row"></param>
        private void averageScore(int row)
        {
            
            for (int i = 0; i < assignments.GetLength(0); i++)
            {
                avg += assignments[row, i];
            }
            avg = avg / assignments.GetLength(0);
        }

        /// <summary>
        /// calculates the grade from the average number
        /// </summary>
        /// <param name="?"></param>
        private void calculateGrade (int avg) 
        {
            if(avg >= 93 && avg <= 100)
            {
                grade = "A";
            }
            else if (avg >= 90 && avg <= 92.9)
            {
                grade = "A-";
            }
            else if (avg >= 87 && avg <= 89.9)
            {
                grade = "B+";
            }
            else if (avg >= 83 && avg <= 86.9)
            {
                grade = "B";
            }
            else if (avg >= 80 && avg <= 82.9)
            {
                grade = "B-";
            }
            else if (avg >= 77 && avg <= 79.9)
            {
                grade = "C+";
            }
            else if (avg >= 73 && avg <= 76.9)
            {
                grade = "C";
            }
            else if (avg >= 70 && avg <= 72.9)
            {
                grade = "C-";
            }
            else if (avg >= 67 && avg <= 69.9)
            {
                grade = "D+";
            }
            else if (avg >= 63 && avg <= 66.9)
            {
                grade = "D";
            }
            else if (avg >= 60 && avg <= 62.9)
            {
                grade = "D-";
            }
            else
            {
                grade = "E";
            }

        }
        /// <summary>
        /// displays the scores entered while finding the AVG and GRADE
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void displayScores_Click(object sender, EventArgs e)
        {
            //output for rich text box
            scoresDisplayed.Text = ""; //resets textbox
            scoresDisplayed.Text += "Student\t\t"; //prints out student
            //for loop to dynamically print out number of assingments
            for (int i = 1; i < numStud; i++)
            {
                scoresDisplayed.Text += "#" + i + "\t\t"; // prints out assignment number
            }
            scoresDisplayed.Text += "AVG\t" + "GRADE\n";

            //for loop to display names and assignment scores

            for (int row = 0; row < assignments.GetLength(0); row++) //loops through rows
            {
                //print name
                scoresDisplayed.Text += name[row] + "\t\t";

                for (int col = 0; col < assignments.GetLength(1); col++)
                {
                    scoresDisplayed.Text += assignments[row, col] + "\t\t"; //prints scores
                }
                //get average score
                averageScore(row);
                calculateGrade(avg); //calculates grade
                scoresDisplayed.Text += avg + "\t" + grade + "\n"; //prints scores on new line
                avg = 0; //sets average back to zero for next round
                grade = ""; //sets grade back to zero for next round
            }




        }

        /// <summary>
        /// resets all functions
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void reset_Click(object sender, EventArgs e)
        {
            scoresDisplayed.Text = ""; //resets rich text box
            Array.Clear(name, 0, name.Length); //reset name array
            Array.Clear(assignments, 0, assignments.Length); //reset assignments array
            numStud = 0; //reset numStud
            position = ""; //reset position
            num = 0; //reset num
            numStudents.Text = ""; //resets number of students 
            numAssignments.Text = ""; //resets number of assignments
            
            
        }//end fillArrayAssignments

    }
}
