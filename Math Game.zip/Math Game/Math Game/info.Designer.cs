﻿namespace Math_Game
{
    partial class info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(info));
            this.label1 = new System.Windows.Forms.Label();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.errorLabel = new System.Windows.Forms.Label();
            this.mainButton = new System.Windows.Forms.Button();
            this.submitInfo = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 27F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Image = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.label1.Location = new System.Drawing.Point(962, 207);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(935, 111);
            this.label1.TabIndex = 1;
            this.label1.Text = "User Information:";
            // 
            // txtUserName
            // 
            this.txtUserName.Font = new System.Drawing.Font("Showcard Gothic", 20F, System.Drawing.FontStyle.Bold);
            this.txtUserName.Location = new System.Drawing.Point(1516, 527);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(296, 90);
            this.txtUserName.TabIndex = 2;
            // 
            // txtAge
            // 
            this.txtAge.Font = new System.Drawing.Font("Showcard Gothic", 20F, System.Drawing.FontStyle.Bold);
            this.txtAge.Location = new System.Drawing.Point(1516, 659);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(155, 90);
            this.txtAge.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Showcard Gothic", 20F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Gold;
            this.label3.Image = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.label3.Location = new System.Drawing.Point(1167, 527);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(241, 83);
            this.label3.TabIndex = 5;
            this.label3.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 20F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Gold;
            this.label2.Image = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.label2.Location = new System.Drawing.Point(1223, 662);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 83);
            this.label2.TabIndex = 6;
            this.label2.Text = "Age:";
            // 
            // errorLabel
            // 
            this.errorLabel.AutoSize = true;
            this.errorLabel.Font = new System.Drawing.Font("Showcard Gothic", 15F, System.Drawing.FontStyle.Bold);
            this.errorLabel.ForeColor = System.Drawing.Color.Red;
            this.errorLabel.Image = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.errorLabel.Location = new System.Drawing.Point(2271, 991);
            this.errorLabel.Name = "errorLabel";
            this.errorLabel.Size = new System.Drawing.Size(0, 62);
            this.errorLabel.TabIndex = 7;
            // 
            // mainButton
            // 
            this.mainButton.BackgroundImage = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.mainButton.Font = new System.Drawing.Font("Showcard Gothic", 15F, System.Drawing.FontStyle.Bold);
            this.mainButton.ForeColor = System.Drawing.Color.White;
            this.mainButton.Location = new System.Drawing.Point(2795, 1552);
            this.mainButton.Name = "mainButton";
            this.mainButton.Size = new System.Drawing.Size(410, 142);
            this.mainButton.TabIndex = 9;
            this.mainButton.Text = "Main Menu";
            this.mainButton.UseVisualStyleBackColor = true;
            this.mainButton.Click += new System.EventHandler(this.mainButton_Click);
            // 
            // submitInfo
            // 
            this.submitInfo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("submitInfo.BackgroundImage")));
            this.submitInfo.Font = new System.Drawing.Font("Showcard Gothic", 15F, System.Drawing.FontStyle.Bold);
            this.submitInfo.ForeColor = System.Drawing.Color.Gold;
            this.submitInfo.Location = new System.Drawing.Point(1482, 925);
            this.submitInfo.Name = "submitInfo";
            this.submitInfo.Size = new System.Drawing.Size(403, 155);
            this.submitInfo.TabIndex = 10;
            this.submitInfo.Text = "Submit";
            this.submitInfo.UseVisualStyleBackColor = true;
            this.submitInfo.Click += new System.EventHandler(this.submitInfo_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Image = global::Math_Game.Properties.Resources.lb5;
            this.pictureBox1.Location = new System.Drawing.Point(2063, 207);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1067, 698);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // info
            // 
            this.AcceptButton = this.submitInfo;
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.ClientSize = new System.Drawing.Size(3250, 1706);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.submitInfo);
            this.Controls.Add(this.mainButton);
            this.Controls.Add(this.errorLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.txtUserName);
            this.Controls.Add(this.label1);
            this.Name = "info";
            this.Text = "info";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label errorLabel;
        private System.Windows.Forms.Button mainButton;
        private System.Windows.Forms.Button submitInfo;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}