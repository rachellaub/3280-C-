﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace Math_Game
{
    public partial class finalScore : Form
    {


        public finalScore()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Hide the high scores form.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void backToMain_Click(object sender, EventArgs e)
        {
            
            try
            {
                var player = new System.Media.SoundPlayer("light-saber-on.wav");
                player.Play();
                //Hides scores
                this.Hide();

            }
            catch (Exception ex)
            {
                //This is the top level method so we want to handle the exception
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Handle the error.
        /// </summary>
        /// <param name="sClass">The class in which the error occurred in.</param>
        /// <param name="sMethod">The method in which the error occurred in.</param>
        private void HandleError(string sClass, string sMethod, string sMessage)
        {
            try
            {
                //Would write to a file or database here.
                MessageBox.Show(sClass + "." + sMethod + " -> " + sMessage);
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllText("C:\\Error.txt", Environment.NewLine +
                                             "HandleError Exception: " + ex.Message);
            }
        }

        /// <summary>
        /// Method for the score
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void finalScoreButton_Click(object sender, EventArgs e)
        {

            try
            {
                helloMessage.Text = "Hello ";
                nameLbl.Text = info.gameName;
                scoreMessage.Text = "Number correct: ";
                correctLbl.Text = play.numCorrect + " ";
                timeLbl.Text = "Time: " + play.timeElapse;

                if (play.numCorrect >= 5)
                { //good scores
                    var player = new System.Media.SoundPlayer("R2D2.wav");
                    player.Play();
                }
                else
                { //bad scores
                    var player = new System.Media.SoundPlayer("imperial_march.wav");
                    player.Play();
                }

                
            }
            catch (Exception ex)
            {
                //This is the top level method so we want to handle the exception
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }
    }
}
