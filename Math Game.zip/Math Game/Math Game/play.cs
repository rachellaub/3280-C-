﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace Math_Game
{
    public partial class play : Form
    {

        /// <summary>
        /// Variable to hold the score
        /// </summary>
        private finalScore copyScore;

        /// <summary>
        /// Keeps track of what math game
        /// </summary>
        string gameType = "";

        /// <summary>
        /// Users answer to question
        /// </summary>
        int userAnswer = 0;

        /// <summary>
        /// Computers answer to question
        /// </summary>
        int compAnswer = 0;

        /// <summary>
        /// Random number 1
        /// </summary>
        int num1 = 0;

        /// <summary>
        /// Random number 2
        /// </summary>
        int num2 = 0;

        /// <summary>
        /// Creating first random number variable
        /// </summary>
        Random randomNum1 = new Random();

        /// <summary>
        /// Creating 2nd random variable
        /// </summary>
        Random randomNum2 = new Random();

        /// <summary>
        /// Keeps track of the number of questions
        /// </summary>
        int numEquation = 0;

        /// <summary>
        /// Number wrong
        /// </summary>
        int wrong = 0;

        /// <summary>
        /// Number right
        /// </summary>
        private static int right = 0;

        /// <summary>
        /// Start of timer
        /// </summary>
        DateTime dt1 = new DateTime();

        /// <summary>
        /// End of timer
        /// </summary>
        DateTime dt2 = new DateTime();

        /// <summary>
        /// Tracks amount of time passed
        /// </summary>
        static TimeSpan ts = new TimeSpan();

        /// <summary>
        /// A timer.
        /// </summary>
        Timer MyTimer;

        /// <summary>
        /// Property to get and set the high scores.
        /// </summary>
        public finalScore CopyHighScores
        {
            get { return copyScore; }
            set { copyScore = value; }
        }

        /// <summary>
        /// property to get and set correct number
        /// </summary>
        public static int numCorrect
        {
            get { return right; }
            set { right = value; }
        }

        /// <summary>
        /// property to get and set time elapsed
        /// </summary>
        public static TimeSpan timeElapse
        {
            get { return ts; }
            set { ts = value; }
        }

        public play()
        {
            InitializeComponent();

            ///Set up the timer
            MyTimer = new Timer();
            MyTimer.Interval = 1000;
            MyTimer.Tick += new EventHandler(MyTimer_Tick);
        }

        /// <summary>
        /// Starts the timer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void MyTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                lblTimer.Text = DateTime.Now.ToString();
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
            
        }

        /// <summary>
        /// Brings to scores page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void getScores_Click(object sender, EventArgs e)
        {
            
            try
            {
                var player = new System.Media.SoundPlayer("blaster-firing.wav");
                player.Play();
                //Hide the game form
                this.Hide();
                //Show the high scores
                copyScore.ShowDialog();
            }
            catch (Exception ex)
            {
                //This is the top level method so we want to handle the exception
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Hide the game form.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void backMain_Click(object sender, EventArgs e)
        {
          
            try
            {
                this.Hide();
                var player = new System.Media.SoundPlayer("light-saber-on.wav");
                player.Play();
            }
            catch (Exception ex)
            {
                //This is the top level method so we want to handle the exception
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Handle the error.
        /// </summary>
        /// <param name="sClass">The class in which the error occurred in.</param>
        /// <param name="sMethod">The method in which the error occurred in.</param>
        private void HandleError(string sClass, string sMethod, string sMessage)
        {
            try
            {
                //Would write to a file or database here.
                MessageBox.Show(sClass + "." + sMethod + " -> " + sMessage);
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllText("C:\\Error.txt", Environment.NewLine +
                                             "HandleError Exception: " + ex.Message);
            }
        }

        /// <summary>
        /// Makes gameType add
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void addButton_Click(object sender, EventArgs e)
        {
            try
            {
                var player = new System.Media.SoundPlayer("Muchfear.wav");
                player.Play();
                gameType = "add";
                equationLbl.Text = "Addition";
                disableButtons();
                addGame();
                dt1 = DateTime.Now;
            }
            catch (Exception ex)
            {
                //This is the top level method so we want to handle the exception
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }

        }

        /// <summary>
        /// Makes game type subtract
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void subtractButton_Click(object sender, EventArgs e)
        {
            try
            {
                var player = new System.Media.SoundPlayer("Muchfear.wav");
                player.Play();
                gameType = "subtract";
                equationLbl.Text = "Subtraction";
                disableButtons();
                subGame();
                dt1 = DateTime.Now;
            }
            catch (Exception ex)
            {
                //This is the top level method so we want to handle the exception
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }

        }

        /// <summary>
        /// makes game type divide
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void divideButton_Click(object sender, EventArgs e)
        {

            try
            {
                var player = new System.Media.SoundPlayer("Muchfear.wav");
                player.Play();
                gameType = "divide";
                equationLbl.Text = "Division";
                disableButtons();
                divGame();
                dt1 = DateTime.Now;
            }
            catch (Exception ex)
            {
                //This is the top level method so we want to handle the exception
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }

        }

        /// <summary>
        /// makes gameType multiply
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void multiplyButton_Click(object sender, EventArgs e)
        {

            try
            {
                var player = new System.Media.SoundPlayer("Muchfear.wav");
                player.Play();
                gameType = "multiply";
                equationLbl.Text = "Multiplication";
                disableButtons();
                multGame();
                dt1 = DateTime.Now;
            }
            catch (Exception ex)
            {
                //This is the top level method so we want to handle the exception
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }

        }

        /// <summary>
        /// disables all the button for the game board
        /// </summary>
        private void disableButtons()
        {
            try
            {
                MyTimer.Start();
                addButton.Enabled = false;
                subtractButton.Enabled = false;
                divideButton.Enabled = false;
                multiplyButton.Enabled = false;
                submitButton.Enabled = true;
                questionLbl.Text = "Question: 1";
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
 
        }
        /// <summary>
        /// Helps with timer, counting when the game is over, clearing information
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void submitButton_Click(object sender, EventArgs e)
        {

            try
            {
                if (numEquation == 10)
                {
                    MyTimer.Stop(); // stops timer
                    lblTimer.Text = ""; //clear timer 
                   
                    //helps get the time lapse
                    dt2 = DateTime.Now; 
                    ts = dt2.Subtract(dt1);
                    ts.ToString();
                    timeElapsed.Text = "Time elapsed: " + ts;


                    //stop game
                    answerTxt.Clear(); //clears text box
                    submitButton.Enabled = false;
                    equationLbl.Text = "Game over";
                    statusLabel.Text = "";
                    getScores.Enabled = true;
                }
                else
                {
                    int questionNum = numEquation + 1;
                    questionLbl.Text = "Question: " + questionNum; //shows the question number
                    userAnswer = Int32.Parse(answerTxt.Text); //users answer

                    if (compAnswer == userAnswer)
                    {
                        statusLabel.Text = "Correct";
                        right++;
                        var player = new System.Media.SoundPlayer("Chewie-chatting.wav");
                        player.Play();
                    }
                    else
                    {
                        statusLabel.Text = "Wrong";
                        wrong++;
                        var player = new System.Media.SoundPlayer("breathing.wav");
                        player.Play();
                    }
                    chooseGameType(); //gets the game type
                }
            }
            catch (Exception ex)
            {
                //This is the top level method so we want to handle the exception
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Gets the Game type
        /// </summary>
        private void chooseGameType()
        {
            try
            {
                if (gameType == "subtract")
                {
                    subGame();
                }
                else if (gameType == "add")
                {
                    addGame();
                }
                else if (gameType == "divide")
                {
                    divGame();
                }
                else if (gameType == "multiply")
                {
                    multGame();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }

        }

        /// <summary>
        /// Gets random values for add
        /// </summary>
        private void addGame()
        {
            try
            {
                num1 = randomNum1.Next(1, 10); //choses random numbers
                num2 = randomNum2.Next(1, 12); //choses random numbers 
                compAnswer = num1 + num2; //answer to question

                equationLbl.Text = num1 + " + " + num2; //output to label

                numEquation++; //increments games played
                answerTxt.Clear(); //clears text box
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
 
        }

        /// <summary>
        /// Get random values for subtract
        /// </summary>
        private void subGame()
        {
            try
            {
                int counter = 0;
                while (counter != 1)
                {
                    num1 = randomNum1.Next(1, 15); //choses random numbers
                    num2 = randomNum2.Next(1, 11); //choses random numbers 

                    if (num1 >= num2)
                    {
                        equationLbl.Text = num1 + " - " + num2;
                        compAnswer = num1 - num2;
                        counter = 1;

                        numEquation++; //increments games played
                        answerTxt.Clear(); //clears text box
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

        /// <summary>
        /// Gets random numbers for division
        /// </summary>
        private void divGame()
        {
            try
            {
                int counter = 0;
                while (counter != 1)
                {
                    num1 = randomNum1.Next(1, 35); //choses random numbers
                    num2 = randomNum2.Next(1, 16); //choses random numbers 

                    if (num1 % num2 == 0)
                    {
                        equationLbl.Text = num1 + " / " + num2;
                        compAnswer = num1 / num2;
                        counter = 1;

                        numEquation++; //increments games played
                        answerTxt.Clear(); //clears text box
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }

        }

        /// <summary>
        /// Gets random numbers for multiplying
        /// </summary>
        private void multGame()
        {
            try
            {
                num1 = randomNum1.Next(1, 5); //choses random numbers
                num2 = randomNum2.Next(1, 8); //choses random numbers 
                compAnswer = num1 * num2; //answer to question

                equationLbl.Text = num1 + " x " + num2; //output to label

                numEquation++; //increments games played
                answerTxt.Clear(); //clears text box
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." +
                                    MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }

        }
    }
}
