﻿namespace Math_Game
{
    partial class finalScore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.helloMessage = new System.Windows.Forms.Label();
            this.finalScoreButton = new System.Windows.Forms.Button();
            this.scoreMessage = new System.Windows.Forms.Label();
            this.backToMain = new System.Windows.Forms.Button();
            this.displayPic = new System.Windows.Forms.PictureBox();
            this.nameLbl = new System.Windows.Forms.Label();
            this.correctLbl = new System.Windows.Forms.Label();
            this.timeLbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.displayPic)).BeginInit();
            this.SuspendLayout();
            // 
            // helloMessage
            // 
            this.helloMessage.AutoSize = true;
            this.helloMessage.Font = new System.Drawing.Font("Showcard Gothic", 21.9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helloMessage.ForeColor = System.Drawing.Color.Gold;
            this.helloMessage.Image = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.helloMessage.Location = new System.Drawing.Point(985, 417);
            this.helloMessage.Name = "helloMessage";
            this.helloMessage.Size = new System.Drawing.Size(0, 92);
            this.helloMessage.TabIndex = 5;
            // 
            // finalScoreButton
            // 
            this.finalScoreButton.BackgroundImage = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.finalScoreButton.Font = new System.Drawing.Font("Showcard Gothic", 20F, System.Drawing.FontStyle.Italic);
            this.finalScoreButton.ForeColor = System.Drawing.Color.Gold;
            this.finalScoreButton.Location = new System.Drawing.Point(1270, 43);
            this.finalScoreButton.Name = "finalScoreButton";
            this.finalScoreButton.Size = new System.Drawing.Size(437, 245);
            this.finalScoreButton.TabIndex = 6;
            this.finalScoreButton.Text = "Click for Score";
            this.finalScoreButton.UseVisualStyleBackColor = true;
            this.finalScoreButton.Click += new System.EventHandler(this.finalScoreButton_Click);
            // 
            // scoreMessage
            // 
            this.scoreMessage.AutoSize = true;
            this.scoreMessage.Font = new System.Drawing.Font("Showcard Gothic", 21.9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreMessage.ForeColor = System.Drawing.Color.Gold;
            this.scoreMessage.Image = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.scoreMessage.Location = new System.Drawing.Point(975, 725);
            this.scoreMessage.Name = "scoreMessage";
            this.scoreMessage.Size = new System.Drawing.Size(0, 92);
            this.scoreMessage.TabIndex = 7;
            // 
            // backToMain
            // 
            this.backToMain.BackgroundImage = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.backToMain.Font = new System.Drawing.Font("Showcard Gothic", 15F, System.Drawing.FontStyle.Bold);
            this.backToMain.ForeColor = System.Drawing.Color.White;
            this.backToMain.Location = new System.Drawing.Point(2517, 1475);
            this.backToMain.Name = "backToMain";
            this.backToMain.Size = new System.Drawing.Size(384, 186);
            this.backToMain.TabIndex = 10;
            this.backToMain.Text = "Main Menu";
            this.backToMain.UseVisualStyleBackColor = true;
            // 
            // displayPic
            // 
            this.displayPic.BackgroundImage = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.displayPic.Image = global::Math_Game.Properties.Resources.gang;
            this.displayPic.Location = new System.Drawing.Point(106, 725);
            this.displayPic.Name = "displayPic";
            this.displayPic.Size = new System.Drawing.Size(783, 818);
            this.displayPic.TabIndex = 11;
            this.displayPic.TabStop = false;
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Font = new System.Drawing.Font("Showcard Gothic", 30F, System.Drawing.FontStyle.Bold);
            this.nameLbl.ForeColor = System.Drawing.Color.White;
            this.nameLbl.Image = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.nameLbl.Location = new System.Drawing.Point(1274, 405);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(0, 124);
            this.nameLbl.TabIndex = 12;
            // 
            // correctLbl
            // 
            this.correctLbl.AutoSize = true;
            this.correctLbl.Font = new System.Drawing.Font("Showcard Gothic", 30F, System.Drawing.FontStyle.Bold);
            this.correctLbl.ForeColor = System.Drawing.Color.White;
            this.correctLbl.Image = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.correctLbl.Location = new System.Drawing.Point(1828, 715);
            this.correctLbl.Name = "correctLbl";
            this.correctLbl.Size = new System.Drawing.Size(0, 124);
            this.correctLbl.TabIndex = 13;
            // 
            // timeLbl
            // 
            this.timeLbl.AutoSize = true;
            this.timeLbl.Font = new System.Drawing.Font("Showcard Gothic", 21.9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timeLbl.ForeColor = System.Drawing.Color.White;
            this.timeLbl.Image = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.timeLbl.Location = new System.Drawing.Point(1002, 961);
            this.timeLbl.Name = "timeLbl";
            this.timeLbl.Size = new System.Drawing.Size(0, 92);
            this.timeLbl.TabIndex = 14;
            // 
            // finalScore
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.ClientSize = new System.Drawing.Size(2953, 1690);
            this.Controls.Add(this.timeLbl);
            this.Controls.Add(this.correctLbl);
            this.Controls.Add(this.nameLbl);
            this.Controls.Add(this.displayPic);
            this.Controls.Add(this.backToMain);
            this.Controls.Add(this.scoreMessage);
            this.Controls.Add(this.finalScoreButton);
            this.Controls.Add(this.helloMessage);
            this.Name = "finalScore";
            this.Text = "finalScore";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.displayPic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label helloMessage;
        private System.Windows.Forms.Button finalScoreButton;
        private System.Windows.Forms.Label scoreMessage;
        private System.Windows.Forms.Button backToMain;
        private System.Windows.Forms.PictureBox displayPic;
        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label correctLbl;
        private System.Windows.Forms.Label timeLbl;
    }
}