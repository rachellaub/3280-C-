﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace Math_Game
{
    public partial class main : Form
    {
    
        /// <summary>
        /// Class that holds the high scores.
        /// </summary>
        finalScore finalScoreTally;

        /// <summary>
        /// Class that holds the user data.
        /// </summary>
        info userInformation;

        /// <summary>
        /// Class where the game is played.
        /// </summary>
        play playGame;
       
        public main()
        {
            InitializeComponent();

            var player = new System.Media.SoundPlayer("theme.wav");
            player.Play();

            finalScoreTally = new finalScore();
            userInformation = new info();
            playGame = new play();
            

            //Pass the high scores form to the game form.  This way the high scores form may be displayed via the game form.
            playGame.CopyHighScores = finalScoreTally;
        }


        /// <summary>
        /// Show the user data form.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void userInfoButton_Click_1(object sender, EventArgs e)
        {
     
            try
            {
                var player = new System.Media.SoundPlayer("light-saber-on.wav");
                player.Play();
                //Hide the menu
                this.Hide();
                //Show the user data form
                userInformation.ShowDialog();
                //Show the main form
                this.Show();
                if (info.information == true)
                {
                    startGameButton.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                //This is the top level method so we want to handle the exception
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Play the game.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void startGameButton_Click_1(object sender, EventArgs e)
        {

            try
            {
                var player = new System.Media.SoundPlayer("light-saber-on.wav");
                player.Play();

                //Hide the menu
                this.Hide();
                //Show the game form
                playGame.ShowDialog();
                //Show the main form
                this.Show();
            }
            catch (Exception ex)
            {
                //This is the top level method so we want to handle the exception
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Handle the error.
        /// </summary>
        /// <param name="sClass">The class in which the error occurred in.</param>
        /// <param name="sMethod">The method in which the error occurred in.</param>
        private void HandleError(string sClass, string sMethod, string sMessage)
        {
            try
            {
                //Would write to a file or database here.
                MessageBox.Show(sClass + "." + sMethod + " -> " + sMessage);
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllText("C:\\Error.txt", Environment.NewLine +
                                             "HandleError Exception: " + ex.Message);
            }
        }
    }
}
