﻿namespace Math_Game
{
    partial class play
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addButton = new System.Windows.Forms.Button();
            this.multiplyButton = new System.Windows.Forms.Button();
            this.divideButton = new System.Windows.Forms.Button();
            this.subtractButton = new System.Windows.Forms.Button();
            this.answerTxt = new System.Windows.Forms.TextBox();
            this.equationLbl = new System.Windows.Forms.Label();
            this.statusLabel = new System.Windows.Forms.Label();
            this.getScores = new System.Windows.Forms.Button();
            this.backMain = new System.Windows.Forms.Button();
            this.submitButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.questionLbl = new System.Windows.Forms.Label();
            this.timeElapsed = new System.Windows.Forms.Label();
            this.lblTimer = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // addButton
            // 
            this.addButton.BackgroundImage = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.addButton.Font = new System.Drawing.Font("Showcard Gothic", 50F, System.Drawing.FontStyle.Italic);
            this.addButton.ForeColor = System.Drawing.Color.Gold;
            this.addButton.Location = new System.Drawing.Point(1304, 323);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(255, 212);
            this.addButton.TabIndex = 0;
            this.addButton.Text = "+";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // multiplyButton
            // 
            this.multiplyButton.BackgroundImage = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.multiplyButton.Font = new System.Drawing.Font("Showcard Gothic", 50F, System.Drawing.FontStyle.Italic);
            this.multiplyButton.ForeColor = System.Drawing.Color.Gold;
            this.multiplyButton.Location = new System.Drawing.Point(2523, 323);
            this.multiplyButton.Name = "multiplyButton";
            this.multiplyButton.Size = new System.Drawing.Size(255, 212);
            this.multiplyButton.TabIndex = 4;
            this.multiplyButton.Text = "x";
            this.multiplyButton.UseVisualStyleBackColor = true;
            this.multiplyButton.Click += new System.EventHandler(this.multiplyButton_Click);
            // 
            // divideButton
            // 
            this.divideButton.BackgroundImage = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.divideButton.Font = new System.Drawing.Font("Showcard Gothic", 50F, System.Drawing.FontStyle.Italic);
            this.divideButton.ForeColor = System.Drawing.Color.Gold;
            this.divideButton.Location = new System.Drawing.Point(2112, 323);
            this.divideButton.Name = "divideButton";
            this.divideButton.Size = new System.Drawing.Size(255, 212);
            this.divideButton.TabIndex = 5;
            this.divideButton.Text = "/";
            this.divideButton.UseVisualStyleBackColor = true;
            this.divideButton.Click += new System.EventHandler(this.divideButton_Click);
            // 
            // subtractButton
            // 
            this.subtractButton.BackgroundImage = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.subtractButton.Font = new System.Drawing.Font("Showcard Gothic", 50F, System.Drawing.FontStyle.Italic);
            this.subtractButton.ForeColor = System.Drawing.Color.Gold;
            this.subtractButton.Location = new System.Drawing.Point(1706, 323);
            this.subtractButton.Name = "subtractButton";
            this.subtractButton.Size = new System.Drawing.Size(255, 212);
            this.subtractButton.TabIndex = 6;
            this.subtractButton.Text = "-";
            this.subtractButton.UseVisualStyleBackColor = true;
            this.subtractButton.Click += new System.EventHandler(this.subtractButton_Click);
            // 
            // answerTxt
            // 
            this.answerTxt.Font = new System.Drawing.Font("Showcard Gothic", 35F, System.Drawing.FontStyle.Italic);
            this.answerTxt.Location = new System.Drawing.Point(2240, 917);
            this.answerTxt.Name = "answerTxt";
            this.answerTxt.Size = new System.Drawing.Size(221, 152);
            this.answerTxt.TabIndex = 7;
            // 
            // equationLbl
            // 
            this.equationLbl.AutoSize = true;
            this.equationLbl.Font = new System.Drawing.Font("Showcard Gothic", 30F, System.Drawing.FontStyle.Italic);
            this.equationLbl.ForeColor = System.Drawing.Color.Yellow;
            this.equationLbl.Image = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.equationLbl.Location = new System.Drawing.Point(1559, 963);
            this.equationLbl.Name = "equationLbl";
            this.equationLbl.Size = new System.Drawing.Size(0, 124);
            this.equationLbl.TabIndex = 8;
            // 
            // statusLabel
            // 
            this.statusLabel.AutoSize = true;
            this.statusLabel.Font = new System.Drawing.Font("Showcard Gothic", 15F, System.Drawing.FontStyle.Italic);
            this.statusLabel.ForeColor = System.Drawing.Color.Blue;
            this.statusLabel.Image = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.statusLabel.Location = new System.Drawing.Point(1926, 1313);
            this.statusLabel.Name = "statusLabel";
            this.statusLabel.Size = new System.Drawing.Size(0, 62);
            this.statusLabel.TabIndex = 9;
            // 
            // getScores
            // 
            this.getScores.BackgroundImage = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.getScores.Enabled = false;
            this.getScores.Font = new System.Drawing.Font("Showcard Gothic", 15F, System.Drawing.FontStyle.Italic);
            this.getScores.ForeColor = System.Drawing.Color.Gold;
            this.getScores.Location = new System.Drawing.Point(2771, 62);
            this.getScores.Name = "getScores";
            this.getScores.Size = new System.Drawing.Size(325, 107);
            this.getScores.TabIndex = 10;
            this.getScores.Text = "Scores";
            this.getScores.UseVisualStyleBackColor = true;
            this.getScores.Click += new System.EventHandler(this.getScores_Click);
            // 
            // backMain
            // 
            this.backMain.BackgroundImage = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.backMain.Font = new System.Drawing.Font("Showcard Gothic", 10F, System.Drawing.FontStyle.Italic);
            this.backMain.ForeColor = System.Drawing.Color.Red;
            this.backMain.Location = new System.Drawing.Point(2829, 1467);
            this.backMain.Name = "backMain";
            this.backMain.Size = new System.Drawing.Size(267, 147);
            this.backMain.TabIndex = 11;
            this.backMain.Text = "Cancel Game";
            this.backMain.UseVisualStyleBackColor = true;
            this.backMain.Click += new System.EventHandler(this.backMain_Click);
            // 
            // submitButton
            // 
            this.submitButton.BackgroundImage = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.submitButton.Enabled = false;
            this.submitButton.Font = new System.Drawing.Font("Showcard Gothic", 20F, System.Drawing.FontStyle.Italic);
            this.submitButton.ForeColor = System.Drawing.Color.Gold;
            this.submitButton.Location = new System.Drawing.Point(2771, 935);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(360, 119);
            this.submitButton.TabIndex = 12;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 25F, System.Drawing.FontStyle.Italic);
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Image = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.label1.Location = new System.Drawing.Point(718, 153);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(803, 103);
            this.label1.TabIndex = 13;
            this.label1.Text = "Select game type";
            // 
            // questionLbl
            // 
            this.questionLbl.AutoSize = true;
            this.questionLbl.Font = new System.Drawing.Font("Showcard Gothic", 15F, System.Drawing.FontStyle.Italic);
            this.questionLbl.ForeColor = System.Drawing.Color.Green;
            this.questionLbl.Image = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.questionLbl.Location = new System.Drawing.Point(1293, 643);
            this.questionLbl.Name = "questionLbl";
            this.questionLbl.Size = new System.Drawing.Size(0, 62);
            this.questionLbl.TabIndex = 14;
            // 
            // timeElapsed
            // 
            this.timeElapsed.AutoSize = true;
            this.timeElapsed.Font = new System.Drawing.Font("Showcard Gothic", 15F, System.Drawing.FontStyle.Italic);
            this.timeElapsed.ForeColor = System.Drawing.Color.Blue;
            this.timeElapsed.Image = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.timeElapsed.Location = new System.Drawing.Point(1726, 120);
            this.timeElapsed.Name = "timeElapsed";
            this.timeElapsed.Size = new System.Drawing.Size(0, 62);
            this.timeElapsed.TabIndex = 15;
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.Font = new System.Drawing.Font("Showcard Gothic", 15F, System.Drawing.FontStyle.Italic);
            this.lblTimer.ForeColor = System.Drawing.Color.Blue;
            this.lblTimer.Image = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.lblTimer.Location = new System.Drawing.Point(2870, 388);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(0, 62);
            this.lblTimer.TabIndex = 16;
            // 
            // play
            // 
            this.AcceptButton = this.submitButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Math_Game.Properties.Resources.Star_Wars_pic;
            this.ClientSize = new System.Drawing.Size(3153, 1672);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.timeElapsed);
            this.Controls.Add(this.questionLbl);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.backMain);
            this.Controls.Add(this.getScores);
            this.Controls.Add(this.statusLabel);
            this.Controls.Add(this.equationLbl);
            this.Controls.Add(this.answerTxt);
            this.Controls.Add(this.subtractButton);
            this.Controls.Add(this.divideButton);
            this.Controls.Add(this.multiplyButton);
            this.Controls.Add(this.addButton);
            this.Name = "play";
            this.Text = "play";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button multiplyButton;
        private System.Windows.Forms.Button divideButton;
        private System.Windows.Forms.Button subtractButton;
        private System.Windows.Forms.TextBox answerTxt;
        private System.Windows.Forms.Label equationLbl;
        private System.Windows.Forms.Label statusLabel;
        private System.Windows.Forms.Button getScores;
        private System.Windows.Forms.Button backMain;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label questionLbl;
        private System.Windows.Forms.Label timeElapsed;
        private System.Windows.Forms.Label lblTimer;
    }
}