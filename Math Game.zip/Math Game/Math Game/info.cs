﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace Math_Game
{
    public partial class info : Form
    {
        /// <summary>
        /// Name of user for score page
        /// </summary>
        private static string playersName = "";
        /// <summary>
        /// Enables or disables for start game button
        /// </summary>
        private static bool informationEntered = false;

        public info()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Brings back to main menu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mainButton_Click(object sender, EventArgs e)
        {
            

            try
            {
                //Hide user data form
                this.Hide();
                var player = new System.Media.SoundPlayer("light-saber-off.wav");
                player.Play();
            }
            catch (Exception ex)
            {
                //This is the top level method so we want to handle the exception
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// Takes in the users name and age
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void submitInfo_Click(object sender, EventArgs e)
        {
            try
            {
                var player = new System.Media.SoundPlayer("R2D2-yeah.wav");
                player.Play();
                informationEntered = true;
                playersName = txtUserName.Text;
                errorLabel.Text = "Hello " + txtUserName.Text;
                submitInfo.Enabled = false;
                txtUserName.Enabled = false;
                txtAge.Enabled = false;
            }
            catch (Exception ex)
            {
                //This is the top level method so we want to handle the exception
                HandleError(MethodInfo.GetCurrentMethod().DeclaringType.Name,
                            MethodInfo.GetCurrentMethod().Name, ex.Message);
            }
        }

        /// <summary>
        /// helps with getting the users name to finalScore
        /// </summary>
        public static string gameName
        {
            get { return playersName; }
            set { playersName = value; }
        }

        /// <summary>
        /// Helps with enabling or disabling start game button
        /// </summary>
        public static bool information
        {
            get { return informationEntered; }
            set { informationEntered = value; }
        }


        /// <summary>
        /// Handle the error.
        /// </summary>
        /// <param name="sClass">The class in which the error occurred in.</param>
        /// <param name="sMethod">The method in which the error occurred in.</param>
        private void HandleError(string sClass, string sMethod, string sMessage)
        {
            try
            {
                //Would write to a file or database here.
                MessageBox.Show(sClass + "." + sMethod + " -> " + sMessage);
            }
            catch (Exception ex)
            {
                System.IO.File.AppendAllText("C:\\Error.txt", Environment.NewLine +
                                             "HandleError Exception: " + ex.Message);
            }
        }
    }
}
