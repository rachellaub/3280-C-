﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A1P1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Button1 is the click button. Once OK is pressed it displays on the app
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void button1_Click(object sender, EventArgs e)
        {
            //This variable type "DialogResult" helps link together the input the user types and the button the user clicks.//
            DialogResult MyResult1;

            //"Show" method is called to create a message box. Then the "Show" is passed the text from the text box. Which is then printed
            //Next the caption is created. Then the message box is given specific buttons and the button icon is decided. 
            //All of this is stored into the MyResult1.
            MyResult1 = MessageBox.Show("You typed: " + textBox1.Text, "This is a caption", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);

            //Prints out what the user clicked.
            label1.Text = "You clicked the " + MyResult1.ToString() + " button";

        }

        /// <summary>
        /// Button2 is the tender but then Retry is the outcome 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            //This variable type "DialogResult" helps link together the input the user types and the button the user clicks.//
            DialogResult MyResult2;

            //"Show" method is called to create a message box. Then the "Show" is passed the text from the text box. Which is then printed
            //Next the caption is created. Then the message box is given specific buttons and the button icon is decided. 
            //All of this is stored into the MyResult2.
            MyResult2 = MessageBox.Show("You typed: " + textBox2.Text, "This is a message", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation);

            //Prints out what the user clicked.
            label2.Text = "You clicked the " + MyResult2.ToString() + " button";
        }
        /// <summary>
        /// button3 is a yes or no question once clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            //This variable type "DialogResult" helps link together the input the user types and the button the user clicks.//
            DialogResult MyResult3;

            //"Show" method is called to create a message box. Then the "Show" is passed the text from the text box. Which is then printed
            //Next the caption is created. Then the message box is given specific buttons and the button icon is decided. 
            //All of this is stored into the MyResult3.
            MyResult3 = MessageBox.Show("You typed: " + textBox3.Text, "This is a yes/no question", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);

            //Prints out what the user clicked.
            label3.Text = "You clicked the " + MyResult3.ToString() + " button";
        }
    }
}
