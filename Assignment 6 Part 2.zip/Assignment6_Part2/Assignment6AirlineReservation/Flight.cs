﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Data;
using System.Data.OleDb;

namespace Assignment6AirlineReservation
{
    /// <summary>
    /// Represents rows in the Flight Table
    /// </summary>
    class Flight
    {
        /// <summary>
        /// The flight's primary key
        /// </summary>
        public int FlightID;

        /// <summary>
        /// The Flight Number
        /// </summary>
        public int FlightNumber;

        /// <summary>
        /// The Aircraft Type
        /// </summary>
        public string AircraftType;

        /// <summary>
        /// Constructs Flight
        /// </summary>
        public Flight(int flightID, int flightNum, string aircraftType)
        {
            try
            {
                this.FlightID = flightID;
                this.FlightNumber = flightNum;
                this.AircraftType = aircraftType;
            }
            catch (Exception ex)
            {
                throw new Exception(MethodInfo.GetCurrentMethod().DeclaringType.Name + "." + MethodInfo.GetCurrentMethod().Name + " -> " + ex.Message);
            }
        }

    }
}
