﻿namespace Start_A3
{
    partial class Scores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.errorMessage = new System.Windows.Forms.Label();
            this.assignmentNumLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.numStudents = new System.Windows.Forms.TextBox();
            this.numAssignments = new System.Windows.Forms.TextBox();
            this.studentName = new System.Windows.Forms.TextBox();
            this.assignmentNum = new System.Windows.Forms.TextBox();
            this.assignmentScore = new System.Windows.Forms.TextBox();
            this.studentNameLabel = new System.Windows.Forms.Label();
            this.submit = new System.Windows.Forms.Button();
            this.reset = new System.Windows.Forms.Button();
            this.lastStudent = new System.Windows.Forms.Button();
            this.nextStudent = new System.Windows.Forms.Button();
            this.prevStudent = new System.Windows.Forms.Button();
            this.firstStudent = new System.Windows.Forms.Button();
            this.saveScore = new System.Windows.Forms.Button();
            this.saveName = new System.Windows.Forms.Button();
            this.displayScores = new System.Windows.Forms.Button();
            this.scoresDisplayed = new System.Windows.Forms.RichTextBox();
            this.OutputFileBtn = new System.Windows.Forms.Button();
            this.FileNameBox = new System.Windows.Forms.TextBox();
            this.FileNameLbl = new System.Windows.Forms.Label();
            this.FileWritingLbl = new System.Windows.Forms.Label();
            this.FileWriteWorker = new System.ComponentModel.BackgroundWorker();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(144, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(269, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Number of students:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(92, 180);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(321, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Number of assignments:";
            // 
            // errorMessage
            // 
            this.errorMessage.AutoSize = true;
            this.errorMessage.Location = new System.Drawing.Point(625, 36);
            this.errorMessage.Name = "errorMessage";
            this.errorMessage.Size = new System.Drawing.Size(0, 32);
            this.errorMessage.TabIndex = 2;
            // 
            // assignmentNumLabel
            // 
            this.assignmentNumLabel.AutoSize = true;
            this.assignmentNumLabel.Location = new System.Drawing.Point(28, 616);
            this.assignmentNumLabel.Name = "assignmentNumLabel";
            this.assignmentNumLabel.Size = new System.Drawing.Size(354, 32);
            this.assignmentNumLabel.TabIndex = 3;
            this.assignmentNumLabel.Text = "Enter Assignment Number:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(160, 687);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(253, 32);
            this.label5.TabIndex = 4;
            this.label5.Text = "Assignment Score:";
            // 
            // numStudents
            // 
            this.numStudents.Location = new System.Drawing.Point(436, 98);
            this.numStudents.Name = "numStudents";
            this.numStudents.Size = new System.Drawing.Size(139, 38);
            this.numStudents.TabIndex = 5;
            // 
            // numAssignments
            // 
            this.numAssignments.Location = new System.Drawing.Point(436, 180);
            this.numAssignments.Name = "numAssignments";
            this.numAssignments.Size = new System.Drawing.Size(135, 38);
            this.numAssignments.TabIndex = 6;
            // 
            // studentName
            // 
            this.studentName.Enabled = false;
            this.studentName.Location = new System.Drawing.Point(324, 440);
            this.studentName.Name = "studentName";
            this.studentName.Size = new System.Drawing.Size(251, 38);
            this.studentName.TabIndex = 7;
            // 
            // assignmentNum
            // 
            this.assignmentNum.Enabled = false;
            this.assignmentNum.Location = new System.Drawing.Point(436, 613);
            this.assignmentNum.Name = "assignmentNum";
            this.assignmentNum.Size = new System.Drawing.Size(139, 38);
            this.assignmentNum.TabIndex = 8;
            // 
            // assignmentScore
            // 
            this.assignmentScore.Enabled = false;
            this.assignmentScore.Location = new System.Drawing.Point(436, 687);
            this.assignmentScore.Name = "assignmentScore";
            this.assignmentScore.Size = new System.Drawing.Size(139, 38);
            this.assignmentScore.TabIndex = 9;
            // 
            // studentNameLabel
            // 
            this.studentNameLabel.AutoSize = true;
            this.studentNameLabel.Location = new System.Drawing.Point(144, 440);
            this.studentNameLabel.Name = "studentNameLabel";
            this.studentNameLabel.Size = new System.Drawing.Size(122, 32);
            this.studentNameLabel.TabIndex = 10;
            this.studentNameLabel.Text = "Student:";
            // 
            // submit
            // 
            this.submit.Location = new System.Drawing.Point(610, 115);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(200, 82);
            this.submit.TabIndex = 11;
            this.submit.Text = "Submit Counts";
            this.submit.UseVisualStyleBackColor = true;
            this.submit.Click += new System.EventHandler(this.submit_Click);
            // 
            // reset
            // 
            this.reset.Enabled = false;
            this.reset.Location = new System.Drawing.Point(1111, 101);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(233, 96);
            this.reset.TabIndex = 12;
            this.reset.Text = "Reset Scores";
            this.reset.UseVisualStyleBackColor = true;
            this.reset.Click += new System.EventHandler(this.reset_Click);
            // 
            // lastStudent
            // 
            this.lastStudent.Enabled = false;
            this.lastStudent.Location = new System.Drawing.Point(852, 297);
            this.lastStudent.Name = "lastStudent";
            this.lastStudent.Size = new System.Drawing.Size(200, 68);
            this.lastStudent.TabIndex = 13;
            this.lastStudent.Text = ">>Last Student";
            this.lastStudent.UseVisualStyleBackColor = true;
            this.lastStudent.Click += new System.EventHandler(this.lastStudent_Click);
            // 
            // nextStudent
            // 
            this.nextStudent.Enabled = false;
            this.nextStudent.Location = new System.Drawing.Point(610, 297);
            this.nextStudent.Name = "nextStudent";
            this.nextStudent.Size = new System.Drawing.Size(200, 68);
            this.nextStudent.TabIndex = 14;
            this.nextStudent.Text = ">Next Student";
            this.nextStudent.UseVisualStyleBackColor = true;
            this.nextStudent.Click += new System.EventHandler(this.nextStudent_Click);
            // 
            // prevStudent
            // 
            this.prevStudent.Enabled = false;
            this.prevStudent.Location = new System.Drawing.Point(371, 297);
            this.prevStudent.Name = "prevStudent";
            this.prevStudent.Size = new System.Drawing.Size(200, 68);
            this.prevStudent.TabIndex = 15;
            this.prevStudent.Text = "<Prev Student";
            this.prevStudent.UseVisualStyleBackColor = true;
            this.prevStudent.Click += new System.EventHandler(this.prevStudent_Click);
            // 
            // firstStudent
            // 
            this.firstStudent.Enabled = false;
            this.firstStudent.Location = new System.Drawing.Point(135, 297);
            this.firstStudent.Name = "firstStudent";
            this.firstStudent.Size = new System.Drawing.Size(200, 68);
            this.firstStudent.TabIndex = 16;
            this.firstStudent.Text = "<<First Student";
            this.firstStudent.UseVisualStyleBackColor = true;
            this.firstStudent.Click += new System.EventHandler(this.firstStudent_Click);
            // 
            // saveScore
            // 
            this.saveScore.Enabled = false;
            this.saveScore.Location = new System.Drawing.Point(620, 631);
            this.saveScore.Name = "saveScore";
            this.saveScore.Size = new System.Drawing.Size(202, 70);
            this.saveScore.TabIndex = 17;
            this.saveScore.Text = "Save Score";
            this.saveScore.UseVisualStyleBackColor = true;
            this.saveScore.Click += new System.EventHandler(this.saveScore_Click);
            // 
            // saveName
            // 
            this.saveName.Enabled = false;
            this.saveName.Location = new System.Drawing.Point(631, 431);
            this.saveName.Name = "saveName";
            this.saveName.Size = new System.Drawing.Size(191, 70);
            this.saveName.TabIndex = 19;
            this.saveName.Text = "Save Name";
            this.saveName.UseVisualStyleBackColor = true;
            this.saveName.Click += new System.EventHandler(this.saveName_Click);
            // 
            // displayScores
            // 
            this.displayScores.Enabled = false;
            this.displayScores.Location = new System.Drawing.Point(620, 734);
            this.displayScores.Name = "displayScores";
            this.displayScores.Size = new System.Drawing.Size(226, 74);
            this.displayScores.TabIndex = 20;
            this.displayScores.Text = "Display Scores";
            this.displayScores.UseVisualStyleBackColor = true;
            this.displayScores.Click += new System.EventHandler(this.displayScores_Click);
            // 
            // scoresDisplayed
            // 
            this.scoresDisplayed.Location = new System.Drawing.Point(98, 944);
            this.scoresDisplayed.Name = "scoresDisplayed";
            this.scoresDisplayed.Size = new System.Drawing.Size(1974, 513);
            this.scoresDisplayed.TabIndex = 21;
            this.scoresDisplayed.Text = "";
            // 
            // OutputFileBtn
            // 
            this.OutputFileBtn.Enabled = false;
            this.OutputFileBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.1F);
            this.OutputFileBtn.Location = new System.Drawing.Point(938, 736);
            this.OutputFileBtn.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.OutputFileBtn.Name = "OutputFileBtn";
            this.OutputFileBtn.Size = new System.Drawing.Size(226, 72);
            this.OutputFileBtn.TabIndex = 22;
            this.OutputFileBtn.Text = "Output To File";
            this.OutputFileBtn.UseVisualStyleBackColor = true;
            this.OutputFileBtn.Click += new System.EventHandler(this.OutputFileBtn_Click);
            // 
            // FileNameBox
            // 
            this.FileNameBox.Enabled = false;
            this.FileNameBox.Location = new System.Drawing.Point(1041, 864);
            this.FileNameBox.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.FileNameBox.Name = "FileNameBox";
            this.FileNameBox.Size = new System.Drawing.Size(201, 38);
            this.FileNameBox.TabIndex = 23;
            // 
            // FileNameLbl
            // 
            this.FileNameLbl.AutoSize = true;
            this.FileNameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.1F);
            this.FileNameLbl.Location = new System.Drawing.Point(873, 864);
            this.FileNameLbl.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.FileNameLbl.Name = "FileNameLbl";
            this.FileNameLbl.Size = new System.Drawing.Size(152, 32);
            this.FileNameLbl.TabIndex = 24;
            this.FileNameLbl.Text = "File Name:";
            // 
            // FileWritingLbl
            // 
            this.FileWritingLbl.AutoSize = true;
            this.FileWritingLbl.Font = new System.Drawing.Font("Franklin Gothic Medium", 7.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FileWritingLbl.Location = new System.Drawing.Point(1288, 864);
            this.FileWritingLbl.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.FileWritingLbl.MaximumSize = new System.Drawing.Size(400, 358);
            this.FileWritingLbl.Name = "FileWritingLbl";
            this.FileWritingLbl.Size = new System.Drawing.Size(0, 32);
            this.FileWritingLbl.TabIndex = 25;
            // 
            // FileWriteWorker
            // 
            this.FileWriteWorker.WorkerReportsProgress = true;
            this.FileWriteWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.FileWriteWorker_DoWork);
            this.FileWriteWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.FileWriteWorker_RunWorkerCompleted);
            // 
            // Scores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2225, 1650);
            this.Controls.Add(this.FileWritingLbl);
            this.Controls.Add(this.FileNameLbl);
            this.Controls.Add(this.FileNameBox);
            this.Controls.Add(this.OutputFileBtn);
            this.Controls.Add(this.scoresDisplayed);
            this.Controls.Add(this.displayScores);
            this.Controls.Add(this.saveName);
            this.Controls.Add(this.saveScore);
            this.Controls.Add(this.firstStudent);
            this.Controls.Add(this.prevStudent);
            this.Controls.Add(this.nextStudent);
            this.Controls.Add(this.lastStudent);
            this.Controls.Add(this.reset);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.studentNameLabel);
            this.Controls.Add(this.assignmentScore);
            this.Controls.Add(this.assignmentNum);
            this.Controls.Add(this.studentName);
            this.Controls.Add(this.numAssignments);
            this.Controls.Add(this.numStudents);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.assignmentNumLabel);
            this.Controls.Add(this.errorMessage);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Scores";
            this.Text = "Scores";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label errorMessage;
        private System.Windows.Forms.Label assignmentNumLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox numStudents;
        private System.Windows.Forms.TextBox numAssignments;
        private System.Windows.Forms.TextBox studentName;
        private System.Windows.Forms.TextBox assignmentNum;
        private System.Windows.Forms.TextBox assignmentScore;
        private System.Windows.Forms.Label studentNameLabel;
        private System.Windows.Forms.Button submit;
        private System.Windows.Forms.Button reset;
        private System.Windows.Forms.Button lastStudent;
        private System.Windows.Forms.Button nextStudent;
        private System.Windows.Forms.Button prevStudent;
        private System.Windows.Forms.Button firstStudent;
        private System.Windows.Forms.Button saveScore;
        private System.Windows.Forms.Button saveName;
        private System.Windows.Forms.Button displayScores;
        private System.Windows.Forms.RichTextBox scoresDisplayed;
        private System.Windows.Forms.Button OutputFileBtn;
        private System.Windows.Forms.TextBox FileNameBox;
        private System.Windows.Forms.Label FileNameLbl;
        private System.Windows.Forms.Label FileWritingLbl;
        private System.ComponentModel.BackgroundWorker FileWriteWorker;
    }
}

