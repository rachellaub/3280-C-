﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace Start_A3
{
    class FileWriter
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public FileWriter() { }

        /// <summary>
        /// Checks to see if provided FilePath is available
        /// </summary>
        /// <param name="FilePath">File Path to check for availability</param>
        /// <returns>boolean representing existance of a file</returns>
        public bool FileExists(String FilePath)
        {
            return File.Exists(FilePath);
        }

        /// <summary>
        /// Write provided Text to provided FilePath
        /// </summary>
        /// <param name="FilePath">Path to which Text should be written</param>
        /// <param name="Text">Text to write to file</param>
        public void WriteToFile(string FilePath, string Text)
        {
            using (StreamWriter FileWriter = new StreamWriter(FilePath))
            {
                FileWriter.WriteAsync(Text);
            }
        }
    }
}
